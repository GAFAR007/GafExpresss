/// lib/app/features/home/presentation/production/production_plan_assistant_screen.dart
/// --------------------------------------------------------------------------------
/// WHAT:
/// - Chat-first assistant screen for creating production plans.
///
/// HOW:
/// - Captures estate/product/date context.
/// - Sends each user turn to the backend assistant endpoint.
/// - Applies returned `plan_draft` into the existing create-plan draft state.
///
/// WHY:
/// - Keeps onboarding simple: users can talk first, then review/edit in form.
/// - Reuses existing plan editor so no duplicate save logic is introduced.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:frontend/app/core/debug/app_debug.dart';
import 'package:frontend/app/core/formatters/date_formatter.dart';
import 'package:frontend/app/features/home/presentation/business_asset_providers.dart';
import 'package:frontend/app/features/home/presentation/business_product_form_sheet.dart';
import 'package:frontend/app/features/home/presentation/business_product_providers.dart';
import 'package:frontend/app/features/home/presentation/product_ai_model.dart';
import 'package:frontend/app/features/home/presentation/product_model.dart';
import 'package:frontend/app/features/home/presentation/production/production_assistant_models.dart';
import 'package:frontend/app/features/home/presentation/production/production_domain_context.dart';
import 'package:frontend/app/features/home/presentation/production/production_plan_draft.dart';
import 'package:frontend/app/features/home/presentation/production/production_providers.dart';
import 'package:frontend/app/features/home/presentation/production/production_routes.dart';

const String _logTag = "PRODUCTION_ASSISTANT_SCREEN";
const String _buildLog = "build()";
const String _sendTurnLog = "send_turn";
const String _sendSuccessLog = "send_success";
const String _sendFailureLog = "send_failure";
const String _openEditorLog = "open_editor";
const String _applyDraftLog = "apply_draft";
const String _suggestionTapLog = "suggestion_tap";
const String _choiceTapLog = "choice_tap";
const String _strictGenerateTapLog = "strict_generate_tap";
const String _quickProductSelectTapLog = "quick_product_select_tap";
const String _strictCreateProductTapLog = "strict_create_product_tap";
const String _strictCreateProductSuccessLog = "strict_create_product_success";
const String _createSuggestedProductTapLog = "create_suggested_product_tap";
const String _createSuggestedProductSuccessLog =
    "create_suggested_product_success";

const String _screenTitle = "AI production assistant";
const String _manualEditorTooltip = "Open editor";
const String _welcomeMessage =
    "Let's collect context first: choose estate, choose product or create one, then generate the full timeline draft.";
const String _useDraftButtonLabel = "Draft production";
const String _noPlanDraftMessage =
    "No draft yet. Select estate + product, then generate draft from context.";
const String _createSuggestedProductLabel = "Create Suggested Product";
const String _assistantErrorMessage = "Assistant request failed. Please retry.";
const String _contextPromptTitle = "Context-first planning";
const String _contextPromptGenerateLabel = "Generate draft from context";
const String _contextPromptCreateProductLabel = "Create new product";
const String _contextPromptMissingContextMessage =
    "Select estate and product first, then generate draft.";
const String _contextPromptQuickProductLabel = "Quick product picks";
const String _contextPromptGeneratingLabel = "Generating...";
const String _contextPromptSkipDatesLabel = "Use AI inferred dates";
const String _guideQuestionBusinessType =
    "What business type are you planning for?";
const String _guideQuestionEstate = "Nice. Which estate should I plan for?";
const String _guideQuestionProduct =
    "Great. Use an existing product or create a new product.";
const String _guideQuestionDates =
    "Do you want to set dates now, or let me infer dates from lifecycle?";
const String _guideQuestionReady =
    "Perfect. I have enough context. Generate your full draft timeline.";
const String _guideContextLabelPrefix = "Current context";
const String _draftPlanSheetTitle = "Draft production schedule";
const String _draftPlanSheetEmpty = "No scheduled tasks were generated.";
const String _draftPlanCloseLabel = "Close";
const String _draftPlanContinueLabel = "Draft production";

const int _queryPage = 1;
const int _queryLimit = 50;
const String _assetTypeEstate = "estate";

class ProductionPlanAssistantScreen extends ConsumerStatefulWidget {
  const ProductionPlanAssistantScreen({super.key});

  @override
  ConsumerState<ProductionPlanAssistantScreen> createState() =>
      _ProductionPlanAssistantScreenState();
}

class _ProductionPlanAssistantScreenState
    extends ConsumerState<ProductionPlanAssistantScreen> {
  final ScrollController _messagesScrollCtrl = ScrollController();

  String? _selectedEstateAssetId;
  String? _selectedProductId;
  DateTime? _startDate;
  DateTime? _endDate;
  bool _useAiInferredDates = false;
  String _domainContext = productionDomainDefault;
  bool _domainExplicitlySelected = false;
  bool _isSending = false;
  String _lastAutoGenerateKey = "";
  final List<_ChatMessage> _messages = [];
  ProductionAssistantTurn? _lastTurn;

  static const Map<String, List<String>> _domainProductKeywords = {
    productionDomainFarm: [
      "rice",
      "bean",
      "maize",
      "cassava",
      "yam",
      "wheat",
      "crop",
      "seed",
      "plant",
      "paddy",
      "tomato",
      "pepper",
    ],
    productionDomainFashion: [
      "shoe",
      "sneaker",
      "shirt",
      "dress",
      "bag",
      "wear",
      "fashion",
      "jacket",
      "jean",
      "trouser",
    ],
    productionDomainFood: [
      "food",
      "snack",
      "meal",
      "bread",
      "drink",
      "juice",
      "sauce",
      "oil",
      "spice",
      "flour",
    ],
    productionDomainCosmetics: [
      "cream",
      "soap",
      "lotion",
      "powder",
      "perfume",
      "cosmetic",
      "serum",
      "oil",
    ],
    productionDomainManufacturing: [
      "part",
      "component",
      "assembly",
      "machine",
      "material",
      "pack",
      "carton",
      "unit",
    ],
    productionDomainConstruction: [
      "cement",
      "block",
      "brick",
      "tile",
      "beam",
      "pipe",
      "paint",
      "wood",
    ],
    productionDomainMedia: [
      "content",
      "video",
      "audio",
      "podcast",
      "ad",
      "campaign",
      "media",
    ],
  };

  @override
  void initState() {
    super.initState();
    // WHY: Greeting message keeps the empty screen actionable immediately.
    _messages.add(
      const _ChatMessage(fromAssistant: true, text: _welcomeMessage),
    );
    _messages.add(
      const _ChatMessage(fromAssistant: true, text: _guideQuestionBusinessType),
    );
  }

  @override
  void dispose() {
    _messagesScrollCtrl.dispose();
    super.dispose();
  }

  void _appendMessage(_ChatMessage message) {
    setState(() => _messages.add(message));
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_messagesScrollCtrl.hasClients) return;
      _messagesScrollCtrl.animateTo(
        _messagesScrollCtrl.position.maxScrollExtent + 72,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  void _appendAssistantMessageOnce(String text) {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    if (_messages.isNotEmpty) {
      final last = _messages.last;
      if (last.fromAssistant && last.text.trim() == trimmed) {
        return;
      }
    }
    _appendMessage(_ChatMessage(fromAssistant: true, text: trimmed));
  }

  void _showSnack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _sendTurn({String? forcedMessage}) async {
    if (_isSending) return;
    final outbound = (forcedMessage ?? "").trim();
    if (outbound.isEmpty) return;

    AppDebug.log(
      _logTag,
      _sendTurnLog,
      extra: {
        "hasEstate": (_selectedEstateAssetId ?? "").isNotEmpty,
        "hasProduct": (_selectedProductId ?? "").isNotEmpty,
        "hasStartDate": _startDate != null,
        "hasEndDate": _endDate != null,
      },
    );

    _appendMessage(_ChatMessage(fromAssistant: false, text: outbound));
    setState(() => _isSending = true);

    try {
      final turnResponse = await ref
          .read(productionPlanActionsProvider)
          .runAssistantTurn(
            payload: {
              "userInput": outbound,
              "estateAssetId": _selectedEstateAssetId ?? "",
              "productId": _selectedProductId ?? "",
              "startDate": _startDate == null
                  ? ""
                  : formatDateInput(_startDate!),
              "endDate": _endDate == null ? "" : formatDateInput(_endDate!),
              "domainContext": _domainContext,
              "businessType": _domainContext,
              "cropSubtype": "",
            },
          );
      final assistantText = turnResponse.turn.message.isNotEmpty
          ? turnResponse.turn.message
          : turnResponse.message;
      _appendMessage(_ChatMessage(fromAssistant: true, text: assistantText));
      setState(() => _lastTurn = turnResponse.turn);
      AppDebug.log(
        _logTag,
        _sendSuccessLog,
        extra: {"action": turnResponse.turn.action},
      );
    } catch (error) {
      AppDebug.log(
        _logTag,
        _sendFailureLog,
        extra: {"error": error.toString()},
      );
      _appendMessage(
        _ChatMessage(
          fromAssistant: true,
          text: _assistantErrorMessage,
          isError: true,
        ),
      );
      _showSnack(_assistantErrorMessage);
    } finally {
      if (mounted) {
        setState(() => _isSending = false);
      }
    }
  }

  Future<void> _pickDate({required bool isStart}) async {
    final initialDate = isStart
        ? (_startDate ?? DateTime.now())
        : (_endDate ?? _startDate ?? DateTime.now());
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(kDatePickerFirstYear),
      lastDate: DateTime(kDatePickerLastYear),
      initialDate: initialDate,
    );
    if (picked == null) return;
    setState(() {
      if (isStart) {
        _startDate = picked;
      } else {
        _endDate = picked;
      }
      // WHY: Manual date picking should switch away from AI-inferred date mode.
      _useAiInferredDates = false;
      _lastAutoGenerateKey = "";
    });
    if (_startDate != null && _endDate != null) {
      _appendAssistantMessageOnce(_guideQuestionReady);
      _tryAutoGenerateDraftFromContext(
        trigger: "manual_dates_ready",
        inferredMode: false,
      );
      return;
    }
    _appendAssistantMessageOnce(_resolveGuideQuestion());
  }

  Future<void> _openManualEditor() async {
    final notifier = ref.read(productionPlanDraftProvider.notifier);
    // WHY: Manual editor entry should still preserve selected context.
    notifier.reset();
    notifier.updateDomainContext(_domainContext);
    notifier.updateEstate(_selectedEstateAssetId);
    notifier.updateProduct(_selectedProductId);
    notifier.updateStartDate(_startDate);
    notifier.updateEndDate(_endDate);
    AppDebug.log(_logTag, _openEditorLog, extra: {"mode": "manual"});
    if (!mounted) return;
    context.push(productionPlanCreateRoute);
  }

  Future<void> _createSuggestedProduct(
    ProductionAssistantDraftProductPayload payload,
  ) async {
    AppDebug.log(_logTag, _createSuggestedProductTapLog);
    final initialDraft = ProductDraft(
      name: payload.createProductPayload.name,
      description: payload.createProductPayload.notes,
      priceNgn: 0,
      stock: 0,
      imageUrl: "",
    );
    final created = await showBusinessProductFormSheet(
      context: context,
      initialDraft: initialDraft,
      onSuccess: (_) async {
        ref.invalidate(
          businessProductsProvider(
            const BusinessProductsQuery(page: _queryPage, limit: _queryLimit),
          ),
        );
      },
    );
    if (created == null) {
      return;
    }
    setState(() => _selectedProductId = created.id);
    AppDebug.log(
      _logTag,
      _createSuggestedProductSuccessLog,
      extra: {"productId": created.id},
    );
    _showSnack("Suggested product created and selected.");
  }

  Future<void> _createProductFromContext() async {
    AppDebug.log(_logTag, _strictCreateProductTapLog);
    final created = await showBusinessProductFormSheet(
      context: context,
      onSuccess: (_) async {
        ref.invalidate(
          businessProductsProvider(
            const BusinessProductsQuery(page: _queryPage, limit: _queryLimit),
          ),
        );
      },
    );
    if (created == null) {
      return;
    }
    setState(() => _selectedProductId = created.id);
    AppDebug.log(
      _logTag,
      _strictCreateProductSuccessLog,
      extra: {"productId": created.id},
    );
    _showSnack("Product created and selected.");
  }

  Future<void> _applyDraftAndOpenEditor(
    ProductionAssistantPlanDraftPayload payload,
  ) async {
    final resolvedProductId = payload.productId.trim().isNotEmpty
        ? payload.productId
        : (_selectedProductId ?? "");
    final phases = payload.phases
        .map(
          (phase) => ProductionPhaseDraft(
            name: phase.name.isEmpty ? "Phase ${phase.order}" : phase.name,
            order: phase.order < 1 ? 1 : phase.order,
            estimatedDays: phase.estimatedDays < 1 ? 1 : phase.estimatedDays,
            tasks: phase.tasks
                .asMap()
                .entries
                .map(
                  (entry) => ProductionTaskDraft(
                    id: "assistant_${phase.order}_${entry.key}_${DateTime.now().millisecondsSinceEpoch}",
                    title: entry.value.title.isEmpty
                        ? "Task"
                        : entry.value.title,
                    roleRequired: entry.value.roleRequired.isEmpty
                        ? "farmer"
                        : entry.value.roleRequired,
                    assignedStaffId: entry.value.assignedStaffProfileIds.isEmpty
                        ? null
                        : entry.value.assignedStaffProfileIds.first,
                    assignedStaffProfileIds:
                        entry.value.assignedStaffProfileIds,
                    requiredHeadcount: entry.value.requiredHeadcount < 1
                        ? 1
                        : entry.value.requiredHeadcount,
                    weight: entry.value.weight < 1 ? 1 : entry.value.weight,
                    instructions: entry.value.instructions,
                    status: ProductionTaskStatus.notStarted,
                    completedAt: null,
                    completedByStaffId: null,
                  ),
                )
                .toList(),
          ),
        )
        .toList();
    final totalTasks = phases.fold<int>(
      0,
      (sum, phase) => sum + phase.tasks.length,
    );
    final startDate = DateTime.tryParse(payload.startDate);
    final endDate = DateTime.tryParse(payload.endDate);
    final riskNotes = payload.warnings
        .map((warning) => warning.message.trim())
        .where((message) => message.isNotEmpty)
        .toList();

    // WHY: Apply assistant draft into the existing create form state.
    final nextState = ProductionPlanDraftState(
      title:
          "${payload.productName.isEmpty ? 'Production' : payload.productName} Plan",
      notes: _messages
          .where((message) => message.fromAssistant)
          .map((message) => message.text.trim())
          .where((message) => message.isNotEmpty)
          .take(2)
          .join("\n"),
      domainContext: _domainContext,
      estateAssetId: _selectedEstateAssetId,
      productId: resolvedProductId.isEmpty ? null : resolvedProductId,
      startDate: startDate,
      endDate: endDate,
      proposedProduct: null,
      productAiSuggested: false,
      startDateAiSuggested: false,
      endDateAiSuggested: false,
      aiGenerated: true,
      totalTasks: totalTasks,
      totalEstimatedDays: payload.days > 0 ? payload.days : 1,
      riskNotes: riskNotes,
      phases: phases,
    );
    ref.read(productionPlanDraftProvider.notifier).applyDraft(nextState);
    AppDebug.log(
      _logTag,
      _applyDraftLog,
      extra: {
        "weeks": payload.weeks,
        "days": payload.days,
        "taskCount": totalTasks,
      },
    );
    if (!mounted) return;
    context.push(productionPlanCreateRoute);
  }

  DateTime _startOfWeekMonday(DateTime value) {
    final day = DateTime(value.year, value.month, value.day);
    return day.subtract(Duration(days: day.weekday - DateTime.monday));
  }

  String _formatTaskTime(DateTime? value) {
    if (value == null) return "--:--";
    final local = value.toLocal();
    final hour = local.hour.toString().padLeft(2, "0");
    final minute = local.minute.toString().padLeft(2, "0");
    return "$hour:$minute";
  }

  List<_AssistantWeeklySchedule> _buildWeeklyScheduleRows(
    ProductionAssistantPlanDraftPayload payload,
  ) {
    final startRaw = DateTime.tryParse(payload.startDate);
    final endRaw = DateTime.tryParse(payload.endDate);
    if (startRaw == null || endRaw == null) {
      AppDebug.log(
        _logTag,
        "draft_schedule_invalid_range",
        extra: {"startDate": payload.startDate, "endDate": payload.endDate},
      );
      return const <_AssistantWeeklySchedule>[];
    }

    final startDate = DateTime(startRaw.year, startRaw.month, startRaw.day);
    final endDate = DateTime(endRaw.year, endRaw.month, endRaw.day);
    final tasksByDay = <String, List<_AssistantScheduleTask>>{};

    for (final phase in payload.phases) {
      for (final task in phase.tasks) {
        if (task.startDate == null || task.dueDate == null) {
          AppDebug.log(
            _logTag,
            "draft_schedule_skip_task_missing_dates",
            extra: {"title": task.title, "phase": phase.name},
          );
          continue;
        }
        final taskStart = task.startDate!.toLocal();
        final taskDue = task.dueDate!.toLocal();
        final day = DateTime(taskStart.year, taskStart.month, taskStart.day);
        final dayKey = formatDateInput(day);
        final list = tasksByDay.putIfAbsent(
          dayKey,
          () => <_AssistantScheduleTask>[],
        );
        list.add(
          _AssistantScheduleTask(
            title: task.title,
            phaseName: phase.name,
            roleRequired: task.roleRequired,
            requiredHeadcount: task.requiredHeadcount,
            startDate: taskStart,
            dueDate: taskDue,
          ),
        );
      }
    }

    for (final entry in tasksByDay.entries) {
      entry.value.sort((left, right) {
        final leftMs = left.startDate.millisecondsSinceEpoch;
        final rightMs = right.startDate.millisecondsSinceEpoch;
        return leftMs.compareTo(rightMs);
      });
    }

    final weeks = <_AssistantWeeklySchedule>[];
    DateTime weekCursor = _startOfWeekMonday(startDate);
    final weekEnd = _startOfWeekMonday(endDate);
    while (!weekCursor.isAfter(weekEnd)) {
      final days = <_AssistantDailySchedule>[];
      for (int offset = 0; offset < 7; offset += 1) {
        final day = weekCursor.add(Duration(days: offset));
        if (day.isBefore(startDate) || day.isAfter(endDate)) {
          continue;
        }
        final dayKey = formatDateInput(day);
        days.add(
          _AssistantDailySchedule(
            date: day,
            tasks: tasksByDay[dayKey] ?? const <_AssistantScheduleTask>[],
          ),
        );
      }
      weeks.add(_AssistantWeeklySchedule(weekStart: weekCursor, days: days));
      weekCursor = weekCursor.add(const Duration(days: 7));
    }

    AppDebug.log(
      _logTag,
      "draft_schedule_grouped",
      extra: {
        "weeks": weeks.length,
        "days": payload.days,
        "taskCount": payload.phases.fold<int>(
          0,
          (sum, phase) => sum + phase.tasks.length,
        ),
      },
    );
    return weeks;
  }

  Future<void> _previewDraftProductionSchedule(
    ProductionAssistantPlanDraftPayload payload,
  ) async {
    final weeklyRows = _buildWeeklyScheduleRows(payload);
    AppDebug.log(
      _logTag,
      "draft_production_preview_open",
      extra: {
        "weeks": weeklyRows.length,
        "days": payload.days,
        "phaseCount": payload.phases.length,
      },
    );

    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.85,
          minChildSize: 0.6,
          maxChildSize: 0.95,
          builder: (context, scrollController) {
            return SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _draftPlanSheetTitle,
                      style: Theme.of(sheetContext).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Range: ${payload.startDate} to ${payload.endDate} (${payload.weeks} weeks)",
                      style: Theme.of(sheetContext).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 10),
                    Expanded(
                      child: weeklyRows.isEmpty
                          ? Center(
                              child: Text(
                                _draftPlanSheetEmpty,
                                style: Theme.of(
                                  sheetContext,
                                ).textTheme.bodyMedium,
                              ),
                            )
                          : ListView.builder(
                              controller: scrollController,
                              itemCount: weeklyRows.length,
                              itemBuilder: (context, weekIndex) {
                                final week = weeklyRows[weekIndex];
                                final weekLabelStart = formatDateLabel(
                                  week.weekStart,
                                );
                                final weekLabelEnd = formatDateLabel(
                                  week.weekStart.add(const Duration(days: 6)),
                                );
                                return Card(
                                  margin: const EdgeInsets.only(bottom: 10),
                                  child: Padding(
                                    padding: const EdgeInsets.all(10),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Week ${weekIndex + 1}: $weekLabelStart to $weekLabelEnd",
                                          style: Theme.of(
                                            sheetContext,
                                          ).textTheme.titleSmall,
                                        ),
                                        const SizedBox(height: 8),
                                        ...week.days.map((day) {
                                          return Padding(
                                            padding: const EdgeInsets.only(
                                              bottom: 8,
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "${_weekdayLabel(day.date.weekday)} ${formatDateLabel(day.date)}",
                                                  style: Theme.of(
                                                    sheetContext,
                                                  ).textTheme.bodyMedium,
                                                ),
                                                const SizedBox(height: 4),
                                                if (day.tasks.isEmpty)
                                                  Text(
                                                    "No task scheduled.",
                                                    style: Theme.of(
                                                      sheetContext,
                                                    ).textTheme.bodySmall,
                                                  )
                                                else
                                                  ...day.tasks.map(
                                                    (task) => Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                            left: 8,
                                                            bottom: 4,
                                                          ),
                                                      child: Text(
                                                        "${_formatTaskTime(task.startDate)} - ${_formatTaskTime(task.dueDate)} | ${task.title} (${task.phaseName}) | ${task.roleRequired} x${task.requiredHeadcount}",
                                                        style: Theme.of(
                                                          sheetContext,
                                                        ).textTheme.bodySmall,
                                                      ),
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          );
                                        }),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        OutlinedButton(
                          onPressed: () => Navigator.of(sheetContext).pop(),
                          child: const Text(_draftPlanCloseLabel),
                        ),
                        const Spacer(),
                        FilledButton.icon(
                          onPressed: () async {
                            Navigator.of(sheetContext).pop();
                            await _applyDraftAndOpenEditor(payload);
                          },
                          icon: const Icon(Icons.check_circle_outline),
                          label: const Text(_draftPlanContinueLabel),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  String _weekdayLabel(int weekday) {
    switch (weekday) {
      case DateTime.monday:
        return "Mon";
      case DateTime.tuesday:
        return "Tue";
      case DateTime.wednesday:
        return "Wed";
      case DateTime.thursday:
        return "Thu";
      case DateTime.friday:
        return "Fri";
      case DateTime.saturday:
        return "Sat";
      case DateTime.sunday:
        return "Sun";
      default:
        return "";
    }
  }

  String _buildStrictGeneratePrompt({
    required String estateName,
    required String productName,
  }) {
    final safeEstate = estateName.trim().isEmpty
        ? "selected estate"
        : estateName.trim();
    final safeProduct = productName.trim().isEmpty
        ? "selected product"
        : productName.trim();
    final startDateText = _startDate == null
        ? ""
        : formatDateInput(_startDate!);
    final endDateText = _endDate == null ? "" : formatDateInput(_endDate!);
    final hasDateRange = startDateText.isNotEmpty && endDateText.isNotEmpty;
    final dateInstruction = hasDateRange
        ? "Use startDate $startDateText and endDate $endDateText."
        : "Infer startDate and endDate from lifecycle and return the total weeks.";
    return "Generate a strict full production plan for $safeProduct at $safeEstate. $dateInstruction Include full-range phases, daily tasks, roleRequired, requiredHeadcount, and warnings.";
  }

  String _resolveSelectedEstateNameFromProvider() {
    final assetsAsync = ref.read(
      businessAssetsProvider(
        const BusinessAssetsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    return assetsAsync.maybeWhen(
      data: (result) {
        for (final asset in result.assets) {
          if (asset.assetType != _assetTypeEstate) {
            continue;
          }
          if (asset.id == _selectedEstateAssetId) {
            return asset.name;
          }
        }
        return "";
      },
      orElse: () => "",
    );
  }

  String _resolveSelectedProductNameFromProvider() {
    final productsAsync = ref.read(
      businessProductsProvider(
        const BusinessProductsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    return productsAsync.maybeWhen(
      data: (products) {
        for (final product in products) {
          if (product.id == _selectedProductId) {
            return product.name;
          }
        }
        return "";
      },
      orElse: () => "",
    );
  }

  String _buildAutoGenerateKey({required bool inferredMode}) {
    final estateId = (_selectedEstateAssetId ?? "").trim();
    final productId = (_selectedProductId ?? "").trim();
    final startText = _startDate == null ? "" : formatDateInput(_startDate!);
    final endText = _endDate == null ? "" : formatDateInput(_endDate!);
    final dateMode = inferredMode ? "infer" : "$startText|$endText";
    return "$estateId|$productId|$dateMode|$_domainContext";
  }

  Future<void> _tryAutoGenerateDraftFromContext({
    required String trigger,
    required bool inferredMode,
  }) async {
    if (_isSending) return;
    final hasEstate = (_selectedEstateAssetId ?? "").trim().isNotEmpty;
    final hasProduct = (_selectedProductId ?? "").trim().isNotEmpty;
    if (!hasEstate || !hasProduct) {
      return;
    }
    if (!inferredMode && !(_startDate != null && _endDate != null)) {
      return;
    }

    final nextKey = _buildAutoGenerateKey(inferredMode: inferredMode);
    if (nextKey == _lastAutoGenerateKey) {
      AppDebug.log(
        _logTag,
        "auto_generate_skipped_duplicate",
        extra: {"trigger": trigger, "key": nextKey},
      );
      return;
    }
    _lastAutoGenerateKey = nextKey;

    final estateName = _resolveSelectedEstateNameFromProvider();
    final productName = _resolveSelectedProductNameFromProvider();
    AppDebug.log(
      _logTag,
      "auto_generate_draft",
      extra: {
        "trigger": trigger,
        "inferredMode": inferredMode,
        "hasStartDate": _startDate != null,
        "hasEndDate": _endDate != null,
      },
    );
    await _generateDraftFromContext(
      estateName: estateName,
      productName: productName,
    );
  }

  String _resolveGuideQuestion() {
    final hasEstate = (_selectedEstateAssetId ?? "").trim().isNotEmpty;
    final hasProduct = (_selectedProductId ?? "").trim().isNotEmpty;
    final hasBothDates = _startDate != null && _endDate != null;
    final hasResolvedDateMode = hasBothDates || _useAiInferredDates;

    if (!_domainExplicitlySelected) {
      return _guideQuestionBusinessType;
    }
    if (!hasEstate) {
      return _guideQuestionEstate;
    }
    if (!hasProduct) {
      return _guideQuestionProduct;
    }
    if (!hasResolvedDateMode) {
      return _guideQuestionDates;
    }
    return _guideQuestionReady;
  }

  List<Product> _filterQuickProductsByDomain({
    required List<Product> products,
    required String domainContext,
  }) {
    final normalizedDomain = normalizeProductionDomainContext(domainContext);
    final keywords =
        _domainProductKeywords[normalizedDomain] ?? const <String>[];
    if (keywords.isEmpty) {
      return products.take(6).toList();
    }
    final ranked = products.where((product) {
      final text = "${product.name} ${product.description}".toLowerCase();
      return keywords.any((keyword) => text.contains(keyword));
    }).toList();
    if (ranked.isNotEmpty) {
      return ranked.take(6).toList();
    }
    return products.take(6).toList();
  }

  void _onDomainContextChanged(String? value) {
    final nextDomain = normalizeProductionDomainContext(value);
    if (nextDomain == _domainContext && _domainExplicitlySelected) {
      return;
    }
    setState(() {
      _domainContext = nextDomain;
      _domainExplicitlySelected = true;
      _lastAutoGenerateKey = "";
    });
    _appendMessage(
      _ChatMessage(
        fromAssistant: false,
        text: "Business type: ${formatProductionDomainLabel(nextDomain)}",
      ),
    );
    _appendAssistantMessageOnce(_resolveGuideQuestion());
  }

  void _skipDateSelectionAndInfer() {
    setState(() {
      _startDate = null;
      _endDate = null;
      // WHY: Explicitly marking this choice prevents date-step loops.
      _useAiInferredDates = true;
      _lastAutoGenerateKey = "";
    });
    _appendMessage(
      const _ChatMessage(fromAssistant: false, text: "Use AI inferred dates."),
    );
    _appendAssistantMessageOnce(_guideQuestionReady);
    _tryAutoGenerateDraftFromContext(
      trigger: "ai_inferred_dates_selected",
      inferredMode: true,
    );
  }

  void _onEstateChanged({
    required String? estateId,
    required String estateName,
  }) {
    if ((_selectedEstateAssetId ?? "") == (estateId ?? "")) {
      return;
    }
    setState(() {
      _selectedEstateAssetId = estateId;
      _lastAutoGenerateKey = "";
    });
    if ((estateId ?? "").trim().isNotEmpty) {
      _appendMessage(
        _ChatMessage(fromAssistant: false, text: "Estate: $estateName"),
      );
    }
    final canAutoWithManualDates = _startDate != null && _endDate != null;
    if (_useAiInferredDates || canAutoWithManualDates) {
      _appendAssistantMessageOnce(_guideQuestionReady);
      _tryAutoGenerateDraftFromContext(
        trigger: "estate_selected_context_ready",
        inferredMode: _useAiInferredDates,
      );
      return;
    }
    _appendAssistantMessageOnce(_resolveGuideQuestion());
  }

  void _onProductChanged({
    required String? productId,
    required String productName,
  }) {
    if ((_selectedProductId ?? "") == (productId ?? "")) {
      return;
    }
    setState(() {
      _selectedProductId = productId;
      _lastAutoGenerateKey = "";
    });
    if ((productId ?? "").trim().isNotEmpty) {
      _appendMessage(
        _ChatMessage(fromAssistant: false, text: "Product: $productName"),
      );
    }
    final canAutoWithManualDates = _startDate != null && _endDate != null;
    if (_useAiInferredDates || canAutoWithManualDates) {
      _appendAssistantMessageOnce(_guideQuestionReady);
      _tryAutoGenerateDraftFromContext(
        trigger: "product_selected_context_ready",
        inferredMode: _useAiInferredDates,
      );
      return;
    }
    _appendAssistantMessageOnce(_resolveGuideQuestion());
  }

  Future<void> _generateDraftFromContext({
    required String estateName,
    required String productName,
  }) async {
    final hasEstate = (_selectedEstateAssetId ?? "").trim().isNotEmpty;
    final hasProduct = (_selectedProductId ?? "").trim().isNotEmpty;
    if (!hasEstate || !hasProduct) {
      _appendMessage(
        const _ChatMessage(
          fromAssistant: true,
          text: _contextPromptMissingContextMessage,
          isError: true,
        ),
      );
      _showSnack(_contextPromptMissingContextMessage);
      return;
    }
    final prompt = _buildStrictGeneratePrompt(
      estateName: estateName,
      productName: productName,
    );
    AppDebug.log(
      _logTag,
      _strictGenerateTapLog,
      extra: {
        "hasEstate": hasEstate,
        "hasProduct": hasProduct,
        "hasStartDate": _startDate != null,
        "hasEndDate": _endDate != null,
      },
    );
    await _sendTurn(forcedMessage: prompt);
  }

  @override
  Widget build(BuildContext context) {
    AppDebug.log(_logTag, _buildLog);
    final theme = Theme.of(context);
    final assetsAsync = ref.watch(
      businessAssetsProvider(
        const BusinessAssetsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    final productsAsync = ref.watch(
      businessProductsProvider(
        const BusinessProductsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    final selectedEstateName = assetsAsync.maybeWhen(
      data: (result) {
        for (final asset in result.assets) {
          if (asset.assetType != _assetTypeEstate) {
            continue;
          }
          if (asset.id == _selectedEstateAssetId) {
            return asset.name;
          }
        }
        return "";
      },
      orElse: () => "",
    );
    final estateNamesById = assetsAsync.maybeWhen(
      data: (result) {
        final map = <String, String>{};
        for (final asset in result.assets) {
          if (asset.assetType != _assetTypeEstate) {
            continue;
          }
          map[asset.id] = asset.name;
        }
        return map;
      },
      orElse: () => const <String, String>{},
    );
    final selectedProductName = productsAsync.maybeWhen(
      data: (products) {
        for (final product in products) {
          if (product.id == _selectedProductId) {
            return product.name;
          }
        }
        return "";
      },
      orElse: () => "",
    );
    final quickProducts = productsAsync.maybeWhen(
      data: (products) => _filterQuickProductsByDomain(
        products: products,
        domainContext: _domainContext,
      ),
      orElse: () => const <Product>[],
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text(_screenTitle),
        actions: [
          IconButton(
            tooltip: _manualEditorTooltip,
            onPressed: _openManualEditor,
            icon: const Icon(Icons.edit_note_outlined),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              controller: _messagesScrollCtrl,
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
              children: [
                ..._messages.map((entry) => _ChatBubble(message: entry)),
                _StrictContextPromptPanel(
                  question: _resolveGuideQuestion(),
                  domainContext: _domainContext,
                  domainExplicitlySelected: _domainExplicitlySelected,
                  hasEstate: (_selectedEstateAssetId ?? "").trim().isNotEmpty,
                  hasProduct: (_selectedProductId ?? "").trim().isNotEmpty,
                  hasStartDate: _startDate != null,
                  hasEndDate: _endDate != null,
                  useAiInferredDates: _useAiInferredDates,
                  selectedEstateName: selectedEstateName,
                  selectedProductName: selectedProductName,
                  selectedEstateAssetId: _selectedEstateAssetId,
                  estateNamesById: estateNamesById,
                  startDate: _startDate,
                  endDate: _endDate,
                  isSending: _isSending,
                  quickProducts: quickProducts,
                  selectedProductId: _selectedProductId,
                  onDomainSelect: (domain) => _onDomainContextChanged(domain),
                  onEstateSelect: (estateId) => _onEstateChanged(
                    estateId: estateId,
                    estateName: estateNamesById[estateId] ?? "Selected estate",
                  ),
                  onPickStartDate: () => _pickDate(isStart: true),
                  onPickEndDate: () => _pickDate(isStart: false),
                  onSkipDates: _skipDateSelectionAndInfer,
                  onQuickProductTap: (product) {
                    AppDebug.log(
                      _logTag,
                      _quickProductSelectTapLog,
                      extra: {
                        "productId": product.id,
                        "productName": product.name,
                      },
                    );
                    _onProductChanged(
                      productId: product.id,
                      productName: product.name,
                    );
                  },
                  onCreateProductTap: _createProductFromContext,
                  onGenerateTap: () => _generateDraftFromContext(
                    estateName: selectedEstateName,
                    productName: selectedProductName,
                  ),
                ),
                _TurnActionPanel(
                  turn: _lastTurn,
                  onSuggestionTap: (value) async {
                    AppDebug.log(
                      _logTag,
                      _suggestionTapLog,
                      extra: {"value": value},
                    );
                    await _sendTurn(forcedMessage: value);
                  },
                  onChoiceTap: (value) async {
                    AppDebug.log(
                      _logTag,
                      _choiceTapLog,
                      extra: {"value": value},
                    );
                    await _sendTurn(forcedMessage: value);
                  },
                  onCreateSuggestedProduct: _createSuggestedProduct,
                  onApplyDraft: _previewDraftProductionSchedule,
                ),
                if (_lastTurn == null)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 8, 0, 0),
                    child: Text(
                      _noPlanDraftMessage,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StrictContextPromptPanel extends StatelessWidget {
  final String question;
  final String domainContext;
  final bool domainExplicitlySelected;
  final bool hasEstate;
  final bool hasProduct;
  final bool hasStartDate;
  final bool hasEndDate;
  final bool useAiInferredDates;
  final String selectedEstateName;
  final String selectedProductName;
  final String? selectedEstateAssetId;
  final Map<String, String> estateNamesById;
  final DateTime? startDate;
  final DateTime? endDate;
  final bool isSending;
  final List<Product> quickProducts;
  final String? selectedProductId;
  final ValueChanged<String> onDomainSelect;
  final ValueChanged<String> onEstateSelect;
  final VoidCallback onPickStartDate;
  final VoidCallback onPickEndDate;
  final VoidCallback onSkipDates;
  final VoidCallback onCreateProductTap;
  final VoidCallback onGenerateTap;
  final ValueChanged<Product> onQuickProductTap;

  const _StrictContextPromptPanel({
    required this.question,
    required this.domainContext,
    required this.domainExplicitlySelected,
    required this.hasEstate,
    required this.hasProduct,
    required this.hasStartDate,
    required this.hasEndDate,
    required this.useAiInferredDates,
    required this.selectedEstateName,
    required this.selectedProductName,
    required this.selectedEstateAssetId,
    required this.estateNamesById,
    required this.startDate,
    required this.endDate,
    required this.isSending,
    required this.quickProducts,
    required this.selectedProductId,
    required this.onDomainSelect,
    required this.onEstateSelect,
    required this.onPickStartDate,
    required this.onPickEndDate,
    required this.onSkipDates,
    required this.onCreateProductTap,
    required this.onGenerateTap,
    required this.onQuickProductTap,
  });

  _GuidedStep _resolveStep() {
    if (!domainExplicitlySelected) {
      return _GuidedStep.businessType;
    }
    if (!hasEstate) {
      return _GuidedStep.estate;
    }
    if (!hasProduct) {
      return _GuidedStep.product;
    }
    if ((!hasStartDate || !hasEndDate) && !useAiInferredDates) {
      return _GuidedStep.dates;
    }
    return _GuidedStep.generate;
  }

  String _stepHintText(_GuidedStep step) {
    switch (step) {
      case _GuidedStep.businessType:
        return "Step 1 of 5: choose business type.";
      case _GuidedStep.estate:
        return "Step 2 of 5: choose estate.";
      case _GuidedStep.product:
        return "Step 3 of 5: choose or create product.";
      case _GuidedStep.dates:
        return "Step 4 of 5: choose dates or infer dates.";
      case _GuidedStep.generate:
        return "Step 5 of 5: generate draft.";
    }
  }

  @override
  Widget build(BuildContext context) {
    final canGenerate = hasEstate && hasProduct;
    final currentStep = _resolveStep();
    final contextLabel = [
      "Business: ${formatProductionDomainLabel(domainContext)}",
      "Estate: ${selectedEstateName.trim().isEmpty ? "Not selected" : selectedEstateName}",
      "Product: ${selectedProductName.trim().isEmpty ? "Not selected" : selectedProductName}",
      "Dates: ${hasStartDate && hasEndDate ? "Set" : "AI infer"}",
    ].join(" | ");
    final estateEntries = estateNamesById.entries.take(8).toList();
    return Card(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _contextPromptTitle,
              style: Theme.of(context).textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            Text(question, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 10),
            Text(
              _guideContextLabelPrefix,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 4),
            Text(contextLabel, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 10),
            if (currentStep == _GuidedStep.businessType)
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: productionDomainValues
                    .map(
                      (domain) => ChoiceChip(
                        label: Text(formatProductionDomainLabel(domain)),
                        selected:
                            normalizeProductionDomainContext(domainContext) ==
                                normalizeProductionDomainContext(domain) &&
                            domainExplicitlySelected,
                        onSelected: (_) => onDomainSelect(domain),
                      ),
                    )
                    .toList(),
              ),
            if (currentStep == _GuidedStep.estate) ...[
              if (estateEntries.isEmpty)
                Text(
                  "No estates yet. Create an estate in Assets, then continue.",
                  style: Theme.of(context).textTheme.bodySmall,
                )
              else
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: estateEntries
                      .map(
                        (entry) => ChoiceChip(
                          label: Text(entry.value),
                          selected: entry.key == selectedEstateAssetId,
                          onSelected: (_) => onEstateSelect(entry.key),
                        ),
                      )
                      .toList(),
                ),
            ],
            if (currentStep == _GuidedStep.product) ...[
              if (quickProducts.isNotEmpty) ...[
                Text(
                  _contextPromptQuickProductLabel,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: quickProducts
                      .map(
                        (product) => ChoiceChip(
                          label: Text(product.name),
                          selected: product.id == selectedProductId,
                          onSelected: (_) => onQuickProductTap(product),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 8),
              ],
              OutlinedButton.icon(
                onPressed: isSending ? null : onCreateProductTap,
                icon: const Icon(Icons.add_box_outlined),
                label: const Text(_contextPromptCreateProductLabel),
              ),
            ],
            if (currentStep == _GuidedStep.dates) ...[
              Row(
                children: [
                  Expanded(
                    child: _DatePickField(
                      label: "Start date",
                      value: startDate,
                      onTap: onPickStartDate,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _DatePickField(
                      label: "End date",
                      value: endDate,
                      onTap: onPickEndDate,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: isSending ? null : onSkipDates,
                child: const Text(_contextPromptSkipDatesLabel),
              ),
            ],
            if (currentStep == _GuidedStep.generate)
              FilledButton.icon(
                onPressed: isSending || !canGenerate ? null : onGenerateTap,
                icon: isSending
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.auto_awesome),
                label: Text(
                  isSending
                      ? _contextPromptGeneratingLabel
                      : _contextPromptGenerateLabel,
                ),
              ),
            const SizedBox(height: 8),
            Text(
              _stepHintText(currentStep),
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

enum _GuidedStep { businessType, estate, product, dates, generate }

class _DatePickField extends StatelessWidget {
  final String label;
  final DateTime? value;
  final VoidCallback onTap;

  const _DatePickField({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: InputDecorator(
        decoration: InputDecoration(labelText: label),
        child: Text(value == null ? "Select" : formatDateLabel(value)),
      ),
    );
  }
}

class _ChatBubble extends StatelessWidget {
  final _ChatMessage message;

  const _ChatBubble({required this.message});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final align = message.fromAssistant
        ? Alignment.centerLeft
        : Alignment.centerRight;
    final bgColor = message.fromAssistant
        ? (message.isError
              ? theme.colorScheme.errorContainer
              : theme.colorScheme.surfaceContainerHighest)
        : theme.colorScheme.primaryContainer;
    final fgColor = message.fromAssistant
        ? (message.isError
              ? theme.colorScheme.onErrorContainer
              : theme.colorScheme.onSurface)
        : theme.colorScheme.onPrimaryContainer;

    return Align(
      alignment: align,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        constraints: const BoxConstraints(maxWidth: 560),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          message.text,
          style: theme.textTheme.bodyMedium?.copyWith(color: fgColor),
        ),
      ),
    );
  }
}

class _TurnActionPanel extends StatelessWidget {
  final ProductionAssistantTurn? turn;
  final Future<void> Function(String value) onSuggestionTap;
  final Future<void> Function(String value) onChoiceTap;
  final Future<void> Function(ProductionAssistantDraftProductPayload payload)
  onCreateSuggestedProduct;
  final Future<void> Function(ProductionAssistantPlanDraftPayload payload)
  onApplyDraft;

  const _TurnActionPanel({
    required this.turn,
    required this.onSuggestionTap,
    required this.onChoiceTap,
    required this.onCreateSuggestedProduct,
    required this.onApplyDraft,
  });

  @override
  Widget build(BuildContext context) {
    final currentTurn = turn;
    if (currentTurn == null) {
      return const SizedBox.shrink();
    }

    final suggestionPayload = currentTurn.suggestionsPayload;
    if (currentTurn.isSuggestions && suggestionPayload != null) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Wrap(
          spacing: 8,
          runSpacing: 8,
          children: suggestionPayload.suggestions
              .map(
                (entry) => ActionChip(
                  label: Text(entry),
                  onPressed: () => onSuggestionTap(entry),
                ),
              )
              .toList(),
        ),
      );
    }

    final clarifyPayload = currentTurn.clarifyPayload;
    if (currentTurn.isClarify && clarifyPayload != null) {
      return Card(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                clarifyPayload.question,
                style: Theme.of(context).textTheme.titleSmall,
              ),
              if (clarifyPayload.contextSummary.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  clarifyPayload.contextSummary,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
              if (clarifyPayload.choices.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: clarifyPayload.choices
                      .map(
                        (entry) => ActionChip(
                          label: Text(entry),
                          onPressed: () => onChoiceTap(entry),
                        ),
                      )
                      .toList(),
                ),
              ],
            ],
          ),
        ),
      );
    }

    final draftProductPayload = currentTurn.draftProductPayload;
    if (currentTurn.isDraftProduct && draftProductPayload != null) {
      final draft = draftProductPayload.draftProduct;
      return Card(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Suggested product",
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 6),
              Text(draft.name),
              Text("Category: ${draft.category}"),
              Text("Unit: ${draft.unit}"),
              Text("Lifecycle: ${draft.lifecycleDaysEstimate} days"),
              if (draft.notes.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(draft.notes, style: Theme.of(context).textTheme.bodySmall),
              ],
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: () => onCreateSuggestedProduct(draftProductPayload),
                icon: const Icon(Icons.add_box_outlined),
                label: const Text(_createSuggestedProductLabel),
              ),
            ],
          ),
        ),
      );
    }

    final planDraftPayload = currentTurn.planDraftPayload;
    if (currentTurn.isPlanDraft && planDraftPayload != null) {
      return Card(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Draft ready: ${planDraftPayload.weeks} weeks (${planDraftPayload.days} days)",
                style: Theme.of(context).textTheme.titleSmall,
              ),
              const SizedBox(height: 6),
              Text("Start: ${planDraftPayload.startDate}"),
              Text("End: ${planDraftPayload.endDate}"),
              Text("Phases: ${planDraftPayload.phases.length}"),
              if (planDraftPayload.warnings.isNotEmpty) ...[
                const SizedBox(height: 6),
                ...planDraftPayload.warnings
                    .take(3)
                    .map((warning) => Text("- ${warning.message}")),
              ],
              const SizedBox(height: 10),
              FilledButton.icon(
                onPressed: () => onApplyDraft(planDraftPayload),
                icon: const Icon(Icons.check_circle_outline),
                label: const Text(_useDraftButtonLabel),
              ),
            ],
          ),
        ),
      );
    }

    return const SizedBox.shrink();
  }
}

class _ChatMessage {
  final bool fromAssistant;
  final String text;
  final bool isError;

  const _ChatMessage({
    required this.fromAssistant,
    required this.text,
    this.isError = false,
  });
}

class _AssistantScheduleTask {
  final String title;
  final String phaseName;
  final String roleRequired;
  final int requiredHeadcount;
  final DateTime startDate;
  final DateTime dueDate;

  const _AssistantScheduleTask({
    required this.title,
    required this.phaseName,
    required this.roleRequired,
    required this.requiredHeadcount,
    required this.startDate,
    required this.dueDate,
  });
}

class _AssistantDailySchedule {
  final DateTime date;
  final List<_AssistantScheduleTask> tasks;

  const _AssistantDailySchedule({required this.date, required this.tasks});
}

class _AssistantWeeklySchedule {
  final DateTime weekStart;
  final List<_AssistantDailySchedule> days;

  const _AssistantWeeklySchedule({required this.weekStart, required this.days});
}
