/// lib/app/features/home/presentation/production/production_plan_create_widgets.dart
/// -----------------------------------------------------------------------------
/// WHAT:
/// - Widgets for production plan creation (form + phase/task editors).
///
/// WHY:
/// - Keeps the create screen under size limits.
/// - Encapsulates reusable form pieces with clear responsibilities.
///
/// HOW:
/// - Uses ProductionPlanDraftController for state updates.
/// - Pulls assets/products/staff from providers.
/// - Logs user actions (adds/removes/submits).
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:frontend/app/core/debug/app_debug.dart';
import 'package:frontend/app/core/formatters/date_formatter.dart';
import 'package:frontend/app/features/home/presentation/business_asset_api.dart';
import 'package:frontend/app/features/home/presentation/business_asset_providers.dart';
import 'package:frontend/app/features/home/presentation/business_product_form_sheet.dart';
import 'package:frontend/app/features/home/presentation/business_product_providers.dart';
import 'package:frontend/app/features/home/presentation/product_ai_model.dart';
import 'package:frontend/app/features/home/presentation/product_model.dart';
import 'package:frontend/app/features/home/presentation/production/production_draft_calendar_preview.dart';
import 'package:frontend/app/features/home/presentation/production/production_domain_context.dart';
import 'package:frontend/app/features/home/presentation/production/production_models.dart';
import 'package:frontend/app/features/home/presentation/production/production_plan_draft.dart';
import 'package:frontend/app/features/home/presentation/production/production_plan_task_table.dart';
import 'package:frontend/app/features/home/presentation/production/production_providers.dart';
import 'package:frontend/app/features/home/presentation/production/production_routes.dart';
import 'package:frontend/app/theme/app_theme.dart';

const String _logTag = "PRODUCTION_CREATE_FORM";
const String _submitAction = "submit_plan";
const String _submitSuccess = "submit_success";
const String _submitFailure = "submit_failure";
const String _addTaskAction = "add_task";
const String _removeTaskAction = "remove_task";
const String _createProductAction = "create_product_tap";
const String _createProductSuccess = "create_product_success";
const String _createProductCancel = "create_product_cancel";
const String _aiDraftAction = "ai_draft_tap";
const String _aiDraftSuccess = "ai_draft_success";
const String _aiDraftFailure = "ai_draft_failure";
const String _aiDraftPartial = "ai_draft_partial";
const String _aiDraftMissing = "ai_draft_missing_fields";
const String _aiDraftCalendarAddTask = "ai_draft_calendar_add_task";
const String _aiSuggestedProductCreateTap = "ai_suggested_product_create_tap";
const String _aiSuggestedProductCreated = "ai_suggested_product_created";
const String _validationFailure = "validation_failed";
const String _extraErrorKey = "error";
const String _extraProductKey = "productId";
const String _extraPhaseKey = "phase";
const String _extraTaskIdKey = "taskId";
const String _extraTaskIndexKey = "taskIndex";
const String _extraHasPromptKey = "hasPrompt";
const String _extraPromptLengthKey = "promptLength";
const String _extraClassificationKey = "classification";
const String _extraErrorCodeKey = "errorCode";
const String _extraIssueTypeKey = "issueType";
const String _extraDomainContextKey = "domainContext";
const String _extraRetryAllowedKey = "retryAllowed";
const String _extraRetryReasonKey = "retryReason";

const String _titleLabel = "Plan title";
const String _notesLabel = "Notes";
const String _notesHint = "Optional notes for this plan";
const String _domainContextLabel = "Business type (optional)";
const String _domainContextHint =
    "Choose a domain to bias AI suggestions. Generic works for any business.";
const String _estateLabel = "Estate";
const String _productLabel = "Product";
const String _createProductLabel = "Create product";
const String _createProductHint = "Add a new product for this plan.";
const String _startDateLabel = "Start date";
const String _endDateLabel = "End date";
const String _workScheduleLabel = "Work schedule";
const String _aiDraftLabel = "AI-generated draft";
const String _aiDraftHelper = "Mark if this plan started as an AI draft.";
const String _aiDraftButtonLabel = "Generate AI draft";
const String _aiDraftApplyButtonLabel = "Draft production";
const String _aiAssistantPromptLabel = "AI assistant brief";
const String _aiAssistantPromptHint =
    "Add constraints, priorities, staffing notes, or risks for this draft.";
const String _aiSummaryLabel = "AI draft summary";
const String _aiSummaryTasksLabel = "Tasks";
const String _aiSummaryDaysLabel = "Estimated days";
const String _aiSummaryRisksLabel = "Risk notes";
const String _aiSummaryNoRisks = "No risks flagged";
const String _aiDraftMissingFields =
    "Select estate and product before generating an AI draft.";
const String _aiDraftSuccessMessage = "AI draft applied.";
const String _aiDraftFailureMessage = "Unable to generate AI draft.";
const String _aiDraftErrorTitle = "AI draft could not be applied";
const String _aiDraftErrorDetailsLabel = "Show details";
const String _aiDraftErrorDetailsHideLabel = "Hide details";
const String _aiDraftRetryLabel = "Retry";
const String _aiDraftSuccessInlineMessage =
    "AI draft ready. Review and adjust tasks.";
const String _aiDraftReadyToApplyMessage =
    "Draft generated. Review the calendar preview, then apply it to the form.";
const String _aiDraftCalendarAddTaskMessage = "Task added to draft day.";
const String _workScheduleLoadingMessage = "Loading schedule policy...";
const String _workScheduleSaveLabel = "Save schedule";
const String _workScheduleAddBlockLabel = "Add block";
const String _workScheduleNoEstateMessage =
    "Select an estate to load the effective work schedule.";
const String _workScheduleSavedMessage = "Schedule policy saved.";
const String _workScheduleSaveErrorMessage = "Unable to save schedule policy.";
const String _aiDraftPartialProductIssue = "PRODUCT_NOT_INFERRED";
const String _aiDraftPartialDateIssue = "DATE_NOT_INFERRED";
const String _aiDraftPartialContextIssue = "INSUFFICIENT_CONTEXT";
const String _aiDraftPartialSchemaIssue = "HARD_SCHEMA_FAILURE";
const String _aiDraftPartialTitle = "We couldn't complete the AI draft yet";
const String _aiDraftPartialProductDescription =
    "The description didn't give enough information to suggest a product.";
const String _aiDraftPartialDateDescription =
    "The description didn't give enough information to suggest plan dates.";
const String _aiDraftPartialContextDescription =
    "The description needs a little more detail so AI can suggest product and schedule.";
const String _aiDraftPartialSchemaDescription =
    "AI output needed manual review, so a safe starter draft was created.";
const String _aiDraftPartialGoodNewsLabel = "Good news:";
const String _aiDraftPartialGoodNewsValue =
    "Your production tasks and plan structure were generated successfully.";
const String _aiDraftPartialSchemaGoodNewsValue =
    "A safe production plan structure was generated for manual completion.";
const String _aiDraftPartialActionsLabel = "Actions:";
const String _aiDraftPartialEditAction = "Edit description";
const String _aiDraftPartialSelectProductAction = "Select product";
const String _aiDraftPartialRetryAction = "Retry AI draft";
const String _aiDraftPartialProductHint =
    "Select a product from the Product field, then retry AI draft.";
const String _aiDraftPartialAppliedMessage =
    "AI draft applied with guidance. Review product and dates before final save.";
const String _aiSuggestedTag = "AI suggested";
const String _aiSuggestedDateHint = "AI suggested date. You can edit this.";
const String _aiSuggestedProductTitle = "AI suggested product draft";
const String _aiSuggestedProductHint =
    "Create this product now or choose an existing product from the list.";
const String _aiSuggestedCreateProductLabel = "Create suggested product";
const String _aiSuggestedProductAppliedMessage =
    "Suggested product created and selected.";
const String _submitLabel = "Create plan";
const String _selectPlaceholder = "Select";
const String _submitError = "Unable to create plan.";
const String _submitSuccessMessage = "Plan created successfully.";
const String _assetTypeEstate = "estate";
// WHY: Keep AI draft payload keys centralized.
const String _draftPayloadEstateId = "estateAssetId";
const String _draftPayloadProductId = "productId";
const String _draftPayloadDomainContext = "domainContext";
const String _draftPayloadStartDate = "startDate";
const String _draftPayloadEndDate = "endDate";
const String _draftPayloadAiBrief = "aiBrief";
const String _draftPayloadCropSubtype = "cropSubtype";
const String _draftPayloadBusinessType = "businessType";

const double _pagePadding = 16;
const double _sectionSpacing = 16;
const double _fieldSpacing = 12;
const double _submitSpinnerSize = 16;
const double _submitSpinnerStroke = 2;

const int _notesMaxLines = 3;
const int _queryPage = 1;
const int _queryLimit = 50;

enum _AiDraftUiState { idle, generating, success, partial, error }

class ProductionPlanCreateBody extends ConsumerStatefulWidget {
  const ProductionPlanCreateBody({super.key});

  @override
  ConsumerState<ProductionPlanCreateBody> createState() =>
      _ProductionPlanCreateBodyState();
}

class _ProductionPlanCreateBodyState
    extends ConsumerState<ProductionPlanCreateBody> {
  bool _isSubmitting = false;

  Future<void> _submitPlan() async {
    if (_isSubmitting) return;
    setState(() {
      _isSubmitting = true;
    });

    final controller = ref.read(productionPlanDraftProvider.notifier);
    // WHY: Block submission until required fields + tasks are ready.
    final errors = controller.validate();
    if (errors.isNotEmpty) {
      AppDebug.log(
        _logTag,
        _validationFailure,
        extra: {_extraErrorKey: errors.first},
      );
      _showSnack(errors.first);
      setState(() {
        _isSubmitting = false;
      });
      return;
    }

    // WHY: Log submission intent before API call.
    AppDebug.log(_logTag, _submitAction);
    try {
      final detail = await ref
          .read(productionPlanActionsProvider)
          .createPlan(payload: controller.toPayload());
      controller.reset();
      if (mounted) {
        _showSnack(_submitSuccessMessage);
        context.go(productionPlanDetailPath(detail.plan.id));
      }
      AppDebug.log(_logTag, _submitSuccess);
    } catch (err) {
      AppDebug.log(
        _logTag,
        _submitFailure,
        extra: {_extraErrorKey: err.toString()},
      );
      if (mounted) {
        _showSnack(_submitError);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final draft = ref.watch(productionPlanDraftProvider);
    // WHY: Fetch estates and products to populate selectors.
    final assetsAsync = ref.watch(
      businessAssetsProvider(
        const BusinessAssetsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    final productsAsync = ref.watch(
      businessProductsProvider(
        const BusinessProductsQuery(page: _queryPage, limit: _queryLimit),
      ),
    );
    // WHY: Staff list is required for task assignments.
    final staffAsync = ref.watch(productionStaffProvider);

    final staffList = staffAsync.valueOrNull ?? [];

    return ListView(
      padding: const EdgeInsets.all(_pagePadding),
      children: [
        _PlanBasicsSection(draft: draft),
        const SizedBox(height: _sectionSpacing),
        _PlanSelectorsSection(
          draft: draft,
          assetsAsync: assetsAsync,
          productsAsync: productsAsync,
        ),
        const SizedBox(height: _sectionSpacing),
        _PlanWorkScheduleSection(estateAssetId: draft.estateAssetId),
        const SizedBox(height: _sectionSpacing),
        _PlanDatesSection(draft: draft),
        const SizedBox(height: _sectionSpacing),
        _PlanAiSection(draft: draft, staffProfiles: staffList),
        const SizedBox(height: _sectionSpacing),
        ProductionPlanTaskTable(
          draft: draft,
          staff: staffList,
          onAddTask: (phaseIndex) {
            final phaseName = draft.phases[phaseIndex].name;
            AppDebug.log(
              _logTag,
              _addTaskAction,
              extra: {_extraPhaseKey: phaseName},
            );
            ref.read(productionPlanDraftProvider.notifier).addTask(phaseIndex);
          },
          onAddTaskAt: (phaseIndex, taskIndex) {
            final phaseName = draft.phases[phaseIndex].name;
            AppDebug.log(
              _logTag,
              _addTaskAction,
              extra: {_extraPhaseKey: phaseName, _extraTaskIndexKey: taskIndex},
            );
            ref
                .read(productionPlanDraftProvider.notifier)
                .addTaskAt(phaseIndex, taskIndex);
          },
          onRemoveTask: (phaseIndex, taskId) {
            final phaseName = draft.phases[phaseIndex].name;
            AppDebug.log(
              _logTag,
              _removeTaskAction,
              extra: {_extraPhaseKey: phaseName, _extraTaskIdKey: taskId},
            );
            ref
                .read(productionPlanDraftProvider.notifier)
                .removeTask(phaseIndex, taskId);
          },
        ),
        const SizedBox(height: _sectionSpacing),
        ElevatedButton.icon(
          onPressed: _isSubmitting ? null : _submitPlan,
          icon: _isSubmitting
              ? const SizedBox(
                  width: _submitSpinnerSize,
                  height: _submitSpinnerSize,
                  child: CircularProgressIndicator(
                    strokeWidth: _submitSpinnerStroke,
                  ),
                )
              : const Icon(Icons.save),
          label: const Text(_submitLabel),
        ),
      ],
    );
  }
}

class _PlanBasicsSection extends ConsumerWidget {
  final ProductionPlanDraftState draft;

  const _PlanBasicsSection({required this.draft});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(productionPlanDraftProvider.notifier);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          initialValue: draft.title,
          decoration: const InputDecoration(labelText: _titleLabel),
          onChanged: controller.updateTitle,
        ),
        const SizedBox(height: _fieldSpacing),
        TextFormField(
          initialValue: draft.notes,
          decoration: const InputDecoration(
            labelText: _notesLabel,
            hintText: _notesHint,
          ),
          maxLines: _notesMaxLines,
          onChanged: controller.updateNotes,
        ),
        const SizedBox(height: _fieldSpacing),
        DropdownButtonFormField<String>(
          initialValue: normalizeProductionDomainContext(draft.domainContext),
          decoration: const InputDecoration(
            labelText: _domainContextLabel,
            helperText: _domainContextHint,
          ),
          items: productionDomainValues
              .map(
                (domain) => DropdownMenuItem(
                  value: domain,
                  child: Text(formatProductionDomainLabel(domain)),
                ),
              )
              .toList(),
          onChanged: controller.updateDomainContext,
        ),
      ],
    );
  }
}

class _PlanSelectorsSection extends ConsumerWidget {
  final ProductionPlanDraftState draft;
  final AsyncValue<BusinessAssetsResult> assetsAsync;
  final AsyncValue<List<Product>> productsAsync;

  const _PlanSelectorsSection({
    required this.draft,
    required this.assetsAsync,
    required this.productsAsync,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(productionPlanDraftProvider.notifier);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        assetsAsync.when(
          data: (result) {
            final estates = result.assets
                .where((asset) => asset.assetType == _assetTypeEstate)
                .toList();
            final selectedEstateId =
                estates.any((asset) => asset.id == draft.estateAssetId)
                ? draft.estateAssetId
                : null;
            return DropdownButtonFormField<String>(
              initialValue: selectedEstateId,
              decoration: const InputDecoration(labelText: _estateLabel),
              hint: const Text(_selectPlaceholder),
              items: estates
                  .map(
                    (asset) => DropdownMenuItem(
                      value: asset.id,
                      child: Text(asset.name),
                    ),
                  )
                  .toList(),
              onChanged: controller.updateEstate,
            );
          },
          loading: () => const LinearProgressIndicator(),
          error: (err, _) => Text(err.toString()),
        ),
        const SizedBox(height: _fieldSpacing),
        productsAsync.when(
          data: (products) {
            final selectedProductId =
                products.any((product) => product.id == draft.productId)
                ? draft.productId
                : null;
            final suggestedProduct = selectedProductId == null
                ? draft.proposedProduct
                : null;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: selectedProductId,
                  decoration: const InputDecoration(labelText: _productLabel),
                  hint: const Text(_selectPlaceholder),
                  items: products
                      .map(
                        (product) => DropdownMenuItem(
                          value: product.id,
                          child: Text(product.name),
                        ),
                      )
                      .toList(),
                  onChanged: controller.updateProduct,
                ),
                if (draft.productAiSuggested && suggestedProduct != null) ...[
                  const SizedBox(height: _fieldSpacing),
                  _AiSuggestedProductCard(
                    draft: suggestedProduct,
                    onCreate: () async {
                      AppDebug.log(_logTag, _aiSuggestedProductCreateTap);
                      final created = await showBusinessProductFormSheet(
                        context: context,
                        initialDraft: suggestedProduct,
                        onSuccess: (_) async {
                          // WHY: Refresh list so the newly created product is selectable.
                          ref.invalidate(
                            businessProductsProvider(
                              const BusinessProductsQuery(
                                page: _queryPage,
                                limit: _queryLimit,
                              ),
                            ),
                          );
                        },
                      );

                      if (created == null) {
                        return;
                      }

                      // WHY: Selecting created product clears AI suggestion mode.
                      controller.updateProduct(created.id);
                      AppDebug.log(
                        _logTag,
                        _aiSuggestedProductCreated,
                        extra: {_extraProductKey: created.id},
                      );
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(_aiSuggestedProductAppliedMessage),
                          ),
                        );
                      }
                    },
                  ),
                ],
                const SizedBox(height: _fieldSpacing),
                // WHY: Let users add a product without leaving the plan flow.
                TextButton.icon(
                  onPressed: () async {
                    AppDebug.log(_logTag, _createProductAction);
                    final created = await showBusinessProductFormSheet(
                      context: context,
                      onSuccess: (_) async {
                        // WHY: Refresh list so the new product appears in the dropdown.
                        ref.invalidate(
                          businessProductsProvider(
                            const BusinessProductsQuery(
                              page: _queryPage,
                              limit: _queryLimit,
                            ),
                          ),
                        );
                      },
                    );

                    if (created == null) {
                      AppDebug.log(_logTag, _createProductCancel);
                      return;
                    }

                    // WHY: Auto-select newly created product for the plan.
                    controller.updateProduct(created.id);
                    AppDebug.log(
                      _logTag,
                      _createProductSuccess,
                      extra: {_extraProductKey: created.id},
                    );
                  },
                  icon: const Icon(Icons.add),
                  label: const Text(_createProductLabel),
                ),
                Text(
                  _createProductHint,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            );
          },
          loading: () => const LinearProgressIndicator(),
          error: (err, _) => Text(err.toString()),
        ),
      ],
    );
  }
}

class _PlanWorkScheduleSection extends ConsumerStatefulWidget {
  final String? estateAssetId;

  const _PlanWorkScheduleSection({required this.estateAssetId});

  @override
  ConsumerState<_PlanWorkScheduleSection> createState() =>
      _PlanWorkScheduleSectionState();
}

class _PlanWorkScheduleSectionState
    extends ConsumerState<_PlanWorkScheduleSection> {
  static const List<int> _weekDays = [1, 2, 3, 4, 5, 6, 7];
  static const Map<int, String> _weekDayLabels = {
    1: "Mon",
    2: "Tue",
    3: "Wed",
    4: "Thu",
    5: "Fri",
    6: "Sat",
    7: "Sun",
  };
  static const List<int> _minSlotOptions = [15, 30, 45, 60, 90, 120, 180, 240];

  String _loadedEstateId = "";
  bool _isSaving = false;
  bool _hasLocalChanges = false;
  List<int> _workWeekDays = [];
  List<_EditableScheduleBlock> _blocks = const [];
  int _minSlotMinutes = 30;
  String _timezone = "";

  @override
  Widget build(BuildContext context) {
    final estateAssetId = widget.estateAssetId?.trim() ?? "";
    if (estateAssetId.isEmpty) {
      return _BuildSectionCard(
        title: _workScheduleLabel,
        child: Text(
          _workScheduleNoEstateMessage,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      );
    }

    final policyAsync = ref.watch(
      productionSchedulePolicyProvider(estateAssetId),
    );
    return _BuildSectionCard(
      title: _workScheduleLabel,
      child: policyAsync.when(
        loading: () => const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LinearProgressIndicator(),
            SizedBox(height: 8),
            Text(_workScheduleLoadingMessage),
          ],
        ),
        error: (error, _) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(error.toString()),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () {
                ref.invalidate(productionSchedulePolicyProvider(estateAssetId));
              },
              child: const Text(_aiDraftRetryLabel),
            ),
          ],
        ),
        data: (response) {
          _ensureLocalPolicyLoaded(
            response: response,
            estateAssetId: estateAssetId,
          );

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _weekDays
                    .map(
                      (day) => FilterChip(
                        selected: _workWeekDays.contains(day),
                        label: Text(_weekDayLabels[day] ?? day.toString()),
                        onSelected: (selected) {
                          setState(() {
                            if (selected) {
                              _workWeekDays = [..._workWeekDays, day]..sort();
                            } else {
                              _workWeekDays = _workWeekDays
                                  .where((value) => value != day)
                                  .toList();
                            }
                            _hasLocalChanges = true;
                          });
                          AppDebug.log(
                            _logTag,
                            "work_schedule_day_toggled",
                            extra: {
                              "estateAssetId": estateAssetId,
                              "day": day,
                              "selected": selected,
                            },
                          );
                        },
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 10),
              ..._blocks.asMap().entries.map((entry) {
                final index = entry.key;
                final block = entry.value;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () =>
                              _pickBlockTime(index: index, isStart: true),
                          child: Text("Start ${block.start}"),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: () =>
                              _pickBlockTime(index: index, isStart: false),
                          child: Text("End ${block.end}"),
                        ),
                      ),
                      const SizedBox(width: 8),
                      IconButton(
                        tooltip: "Remove block",
                        onPressed: _blocks.length <= 1
                            ? null
                            : () {
                                setState(() {
                                  final next = [..._blocks];
                                  next.removeAt(index);
                                  _blocks = next;
                                  _hasLocalChanges = true;
                                });
                              },
                        icon: const Icon(Icons.delete_outline),
                      ),
                    ],
                  ),
                );
              }),
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    _blocks = [
                      ..._blocks,
                      const _EditableScheduleBlock(
                        start: "09:00",
                        end: "12:00",
                      ),
                    ];
                    _hasLocalChanges = true;
                  });
                },
                icon: const Icon(Icons.add),
                label: const Text(_workScheduleAddBlockLabel),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<int>(
                initialValue: _minSlotMinutes,
                decoration: const InputDecoration(
                  labelText: "Minimum slot (minutes)",
                ),
                items: _minSlotOptions
                    .map(
                      (value) => DropdownMenuItem(
                        value: value,
                        child: Text(value.toString()),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value == null) return;
                  setState(() {
                    _minSlotMinutes = value;
                    _hasLocalChanges = true;
                  });
                },
              ),
              const SizedBox(height: 8),
              Text(
                "Timezone: ${_timezone.trim().isEmpty ? 'Local' : _timezone}",
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _isSaving
                      ? null
                      : () => _savePolicy(estateAssetId),
                  icon: _isSaving
                      ? const SizedBox(
                          width: _submitSpinnerSize,
                          height: _submitSpinnerSize,
                          child: CircularProgressIndicator(
                            strokeWidth: _submitSpinnerStroke,
                          ),
                        )
                      : const Icon(Icons.save_outlined),
                  label: const Text(_workScheduleSaveLabel),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  void _ensureLocalPolicyLoaded({
    required ProductionSchedulePolicyResponse response,
    required String estateAssetId,
  }) {
    if (_loadedEstateId == estateAssetId && _hasLocalChanges) {
      return;
    }
    if (_loadedEstateId == estateAssetId &&
        !_hasLocalChanges &&
        _blocks.isNotEmpty) {
      return;
    }
    _loadedEstateId = estateAssetId;
    _workWeekDays = [...response.policy.workWeekDays];
    _blocks = response.policy.blocks
        .map(
          (block) => _EditableScheduleBlock(start: block.start, end: block.end),
        )
        .toList();
    _minSlotMinutes = response.policy.minSlotMinutes;
    _timezone = response.policy.timezone;
    _hasLocalChanges = false;
    AppDebug.log(
      _logTag,
      "work_schedule_loaded",
      extra: {
        "estateAssetId": estateAssetId,
        "workWeekDays": _workWeekDays,
        "blockCount": _blocks.length,
        "minSlotMinutes": _minSlotMinutes,
      },
    );
  }

  Future<void> _pickBlockTime({
    required int index,
    required bool isStart,
  }) async {
    if (index < 0 || index >= _blocks.length) return;
    final current = _blocks[index];
    final initial = _parseClock(
      isStart ? current.start : current.end,
      fallback: isStart
          ? const TimeOfDay(hour: 9, minute: 0)
          : const TimeOfDay(hour: 12, minute: 0),
    );
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked == null) return;
    final text = _formatClock(picked);
    setState(() {
      final next = [..._blocks];
      final updated = isStart
          ? current.copyWith(start: text)
          : current.copyWith(end: text);
      next[index] = updated;
      _blocks = next;
      _hasLocalChanges = true;
    });
  }

  Future<void> _savePolicy(String estateAssetId) async {
    if (_isSaving) return;
    final validationError = _validateLocalPolicy();
    if (validationError != null) {
      _showSnack(validationError);
      return;
    }

    setState(() => _isSaving = true);
    try {
      final payload = {
        "workWeekDays": _workWeekDays,
        "blocks": _blocks
            .map((block) => {"start": block.start, "end": block.end})
            .toList(),
        "minSlotMinutes": _minSlotMinutes,
        "timezone": _timezone,
      };
      final updated = await ref
          .read(productionPlanActionsProvider)
          .updateSchedulePolicy(estateAssetId: estateAssetId, payload: payload);
      setState(() {
        _workWeekDays = [...updated.policy.workWeekDays];
        _blocks = updated.policy.blocks
            .map(
              (block) =>
                  _EditableScheduleBlock(start: block.start, end: block.end),
            )
            .toList();
        _minSlotMinutes = updated.policy.minSlotMinutes;
        _timezone = updated.policy.timezone;
        _hasLocalChanges = false;
      });
      AppDebug.log(
        _logTag,
        "work_schedule_saved",
        extra: {
          "estateAssetId": estateAssetId,
          "workWeekDays": _workWeekDays,
          "blockCount": _blocks.length,
          "minSlotMinutes": _minSlotMinutes,
        },
      );
      _showSnack(_workScheduleSavedMessage);
    } catch (error) {
      AppDebug.log(
        _logTag,
        "work_schedule_save_failed",
        extra: {
          "estateAssetId": estateAssetId,
          _extraErrorKey: error.toString(),
        },
      );
      _showSnack(_workScheduleSaveErrorMessage);
    } finally {
      if (mounted) {
        setState(() => _isSaving = false);
      }
    }
  }

  String? _validateLocalPolicy() {
    if (_workWeekDays.isEmpty) {
      return "Select at least one work day.";
    }
    if (_blocks.isEmpty) {
      return "Add at least one work block.";
    }
    if (_minSlotMinutes < 15 || _minSlotMinutes > 240) {
      return "Minimum slot must be between 15 and 240 minutes.";
    }

    final ranges = <_BlockRange>[];
    for (final block in _blocks) {
      final startMinutes = _clockMinutes(block.start);
      final endMinutes = _clockMinutes(block.end);
      if (startMinutes == null || endMinutes == null) {
        return "Each work block must have valid start and end time.";
      }
      if (startMinutes >= endMinutes) {
        return "Each work block must have start time before end time.";
      }
      ranges.add(_BlockRange(start: startMinutes, end: endMinutes));
    }
    ranges.sort((a, b) => a.start.compareTo(b.start));
    for (var i = 1; i < ranges.length; i += 1) {
      if (ranges[i].start < ranges[i - 1].end) {
        return "Work blocks cannot overlap.";
      }
    }
    return null;
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  TimeOfDay _parseClock(String value, {required TimeOfDay fallback}) {
    final parts = value.split(':');
    if (parts.length != 2) return fallback;
    final hour = int.tryParse(parts[0]) ?? fallback.hour;
    final minute = int.tryParse(parts[1]) ?? fallback.minute;
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return fallback;
    return TimeOfDay(hour: hour, minute: minute);
  }

  String _formatClock(TimeOfDay value) {
    final hour = value.hour.toString().padLeft(2, '0');
    final minute = value.minute.toString().padLeft(2, '0');
    return "$hour:$minute";
  }

  int? _clockMinutes(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null) return null;
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return (hour * 60) + minute;
  }
}

class _EditableScheduleBlock {
  final String start;
  final String end;

  const _EditableScheduleBlock({required this.start, required this.end});

  _EditableScheduleBlock copyWith({String? start, String? end}) {
    return _EditableScheduleBlock(
      start: start ?? this.start,
      end: end ?? this.end,
    );
  }
}

class _BlockRange {
  final int start;
  final int end;

  const _BlockRange({required this.start, required this.end});
}

class _BuildSectionCard extends StatelessWidget {
  final String title;
  final Widget child;

  const _BuildSectionCard({required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

class _PlanDatesSection extends ConsumerWidget {
  final ProductionPlanDraftState draft;

  const _PlanDatesSection({required this.draft});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(productionPlanDraftProvider.notifier);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _DateField(
          label: _startDateLabel,
          value: draft.startDate,
          aiSuggested: draft.startDateAiSuggested,
          onSelected: controller.updateStartDate,
        ),
        const SizedBox(height: _fieldSpacing),
        _DateField(
          label: _endDateLabel,
          value: draft.endDate,
          aiSuggested: draft.endDateAiSuggested,
          onSelected: controller.updateEndDate,
        ),
      ],
    );
  }
}

class _DateField extends StatelessWidget {
  final String label;
  final DateTime? value;
  final bool aiSuggested;
  final ValueChanged<DateTime?> onSelected;

  const _DateField({
    required this.label,
    required this.value,
    required this.aiSuggested,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        InkWell(
          onTap: () async {
            // WHY: Use a date picker to prevent invalid date input.
            final now = DateTime.now();
            final initial = value ?? now;
            final picked = await showDatePicker(
              context: context,
              firstDate: DateTime(kDatePickerFirstYear),
              lastDate: DateTime(kDatePickerLastYear),
              initialDate: initial,
            );
            if (picked != null) {
              onSelected(picked);
            }
          },
          child: InputDecorator(
            decoration: InputDecoration(labelText: label),
            child: Text(
              value == null ? _selectPlaceholder : formatDateLabel(value),
            ),
          ),
        ),
        if (aiSuggested) ...[
          const SizedBox(height: 6),
          const _AiSuggestedHint(message: _aiSuggestedDateHint),
        ],
      ],
    );
  }
}

class _AiSuggestedProductCard extends StatelessWidget {
  final ProductDraft draft;
  final VoidCallback onCreate;

  const _AiSuggestedProductCard({required this.draft, required this.onCreate});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _AiSuggestedHint(message: _aiSuggestedTag),
          const SizedBox(height: 8),
          Text(
            _aiSuggestedProductTitle,
            style: textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(draft.name, style: textTheme.bodyMedium),
          if (draft.description.trim().isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              draft.description,
              style: textTheme.bodySmall?.copyWith(
                color: colorScheme.onSurfaceVariant,
              ),
            ),
          ],
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            runSpacing: 6,
            children: [
              Text(
                "Price: NGN ${draft.priceNgn}",
                style: textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
              Text(
                "Stock: ${draft.stock}",
                style: textTheme.bodySmall?.copyWith(
                  color: colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _aiSuggestedProductHint,
            style: textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: onCreate,
            icon: const Icon(Icons.add_box_outlined),
            label: const Text(_aiSuggestedCreateProductLabel),
          ),
        ],
      ),
    );
  }
}

class _AiSuggestedHint extends StatelessWidget {
  final String message;

  const _AiSuggestedHint({required this.message});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: theme.colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        message,
        style: theme.textTheme.labelSmall?.copyWith(
          color: theme.colorScheme.onSecondaryContainer,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class _PlanAiSection extends ConsumerStatefulWidget {
  final ProductionPlanDraftState draft;
  final List<BusinessStaffProfileSummary> staffProfiles;

  const _PlanAiSection({required this.draft, required this.staffProfiles});

  @override
  ConsumerState<_PlanAiSection> createState() => _PlanAiSectionState();
}

class _PlanAiSectionState extends ConsumerState<_PlanAiSection> {
  _AiDraftUiState _uiState = _AiDraftUiState.idle;
  ProductionAiDraftError? _lastError;
  ProductionAiDraftPartialIssue? _lastPartialIssue;
  ProductionAiDraftResult? _generatedDraft;
  Map<int, ProductionDraftTaskOverride> _draftTaskOverrides =
      <int, ProductionDraftTaskOverride>{};
  bool _showErrorDetails = false;
  // WHY: Prompt lets users steer AI output with operational context.
  final TextEditingController _assistantPromptCtrl = TextEditingController();
  final FocusNode _assistantPromptFocusNode = FocusNode();

  @override
  void dispose() {
    _assistantPromptCtrl.dispose();
    _assistantPromptFocusNode.dispose();
    super.dispose();
  }

  bool get _hasRequiredFields {
    // WHY: Estate + product are mandatory; AI may infer start/end when they are not provided.
    return widget.draft.estateAssetId != null &&
        widget.draft.estateAssetId!.trim().isNotEmpty &&
        widget.draft.productId != null &&
        widget.draft.productId!.trim().isNotEmpty;
  }

  Future<void> _generateDraft() async {
    if (_uiState == _AiDraftUiState.generating) return;
    if (!_hasRequiredFields) {
      final missingFieldsError = ProductionAiDraftError(
        message: _aiDraftMissingFields,
        classification: "MISSING_REQUIRED_FIELD",
        errorCode: "PRODUCTION_AI_CONTEXT_REQUIRED",
        resolutionHint:
            "Select estate/product and retry. Start/end dates are optional because AI can infer them.",
        details: <String, dynamic>{
          "missing": [
            if (widget.draft.estateAssetId == null ||
                widget.draft.estateAssetId!.trim().isEmpty)
              _draftPayloadEstateId,
            if (widget.draft.productId == null ||
                widget.draft.productId!.trim().isEmpty)
              _draftPayloadProductId,
          ],
          "invalid": [],
        },
        retryAllowed: true,
        retryReason: "missing_required_context",
        statusCode: 400,
      );
      // WHY: Prevent unnecessary AI calls when required fields are missing.
      AppDebug.log(
        _logTag,
        _aiDraftMissing,
        extra: {
          _extraErrorKey: missingFieldsError.message,
          _extraClassificationKey: missingFieldsError.classification,
          _extraErrorCodeKey: missingFieldsError.errorCode,
        },
      );
      if (mounted) {
        setState(() {
          _uiState = _AiDraftUiState.error;
          _lastError = missingFieldsError;
          _lastPartialIssue = null;
          _generatedDraft = null;
          _draftTaskOverrides = <int, ProductionDraftTaskOverride>{};
          _showErrorDetails = false;
        });
      }
      return;
    }

    setState(() {
      // WHY: Keep state explicit to drive loading/success/error UI.
      _uiState = _AiDraftUiState.generating;
      _lastError = null;
      _lastPartialIssue = null;
      _generatedDraft = null;
      _draftTaskOverrides = <int, ProductionDraftTaskOverride>{};
      _showErrorDetails = false;
    });

    // WHY: Log the generation tap for UX analytics.
    final prompt = _assistantPromptCtrl.text.trim();
    AppDebug.log(
      _logTag,
      _aiDraftAction,
      extra: {
        _extraHasPromptKey: prompt.isNotEmpty,
        _extraPromptLengthKey: prompt.length,
        _extraDomainContextKey: normalizeProductionDomainContext(
          widget.draft.domainContext,
        ),
      },
    );
    try {
      final payload = {
        _draftPayloadEstateId: widget.draft.estateAssetId,
        _draftPayloadProductId: widget.draft.productId,
        _draftPayloadDomainContext: normalizeProductionDomainContext(
          widget.draft.domainContext,
        ),
        _draftPayloadStartDate: widget.draft.startDate?.toIso8601String(),
        _draftPayloadEndDate: widget.draft.endDate?.toIso8601String(),
        _draftPayloadAiBrief: prompt,
        _draftPayloadBusinessType: normalizeProductionDomainContext(
          widget.draft.domainContext,
        ),
        _draftPayloadCropSubtype: "",
      };
      // WHY: Generate draft first; managers should preview calendar before apply.
      final draftResult = await ref
          .read(productionPlanActionsProvider)
          .generateAiDraft(payload: payload);
      final partialIssue = draftResult.partialIssue;
      if (partialIssue != null) {
        // WHY: Partial AI drafts should guide users without blocking progress.
        AppDebug.log(
          _logTag,
          _aiDraftPartial,
          extra: {_extraIssueTypeKey: partialIssue.issueType},
        );
      } else {
        // WHY: Mark success so the user knows the draft updated.
        AppDebug.log(_logTag, _aiDraftSuccess);
      }
      if (mounted) {
        setState(() {
          _uiState = partialIssue == null
              ? _AiDraftUiState.success
              : _AiDraftUiState.partial;
          _lastError = null;
          _lastPartialIssue = partialIssue;
          _generatedDraft = draftResult;
          _showErrorDetails = false;
        });
        _showSnack(
          partialIssue == null
              ? _aiDraftReadyToApplyMessage
              : _aiDraftPartialAppliedMessage,
        );
      }
    } catch (err) {
      final mappedError = _toAiDraftError(err);
      // WHY: Log failures with details to debug AI draft generation.
      AppDebug.log(
        _logTag,
        _aiDraftFailure,
        extra: {
          _extraErrorKey: mappedError.message,
          _extraClassificationKey: mappedError.classification,
          _extraErrorCodeKey: mappedError.errorCode,
          _extraRetryAllowedKey: mappedError.retryAllowed,
          _extraRetryReasonKey: mappedError.retryReason,
        },
      );
      if (mounted) {
        setState(() {
          _uiState = _AiDraftUiState.error;
          _lastError = mappedError;
          _lastPartialIssue = null;
          _generatedDraft = null;
          _draftTaskOverrides = <int, ProductionDraftTaskOverride>{};
          _showErrorDetails = false;
        });
        _showSnack(_aiDraftFailureMessage);
      }
    } finally {
      if (mounted) {
        // WHY: No-op; state transitions are explicit in success/error branches.
      }
    }
  }

  void _applyGeneratedDraft() {
    final generated = _generatedDraft;
    if (generated == null) return;
    final draftWithOverrides = _buildDraftWithOverrides(generated.draft);
    ref
        .read(productionPlanDraftProvider.notifier)
        .applyDraft(draftWithOverrides);
    AppDebug.log(
      _logTag,
      "ai_draft_applied_after_preview",
      extra: {
        "taskCount": generated.tasks.length,
        "warningCount": generated.warnings.length,
        "overrideCount": _draftTaskOverrides.length,
      },
    );
    _showSnack(_aiDraftSuccessMessage);
  }

  void _onPreviewAddTaskForDay(DateTime day, String phaseNameHint) {
    final generated = _generatedDraft;
    if (generated == null) {
      return;
    }

    // WHY: Apply existing preview overrides first so no user edits are lost.
    final baseDraft = _buildDraftWithOverrides(generated.draft);
    if (baseDraft.phases.isEmpty) {
      return;
    }

    final phaseIndex = _resolvePhaseIndexForCalendarPreview(
      phases: baseDraft.phases,
      phaseNameHint: phaseNameHint,
    );
    final targetPhase = baseDraft.phases[phaseIndex];
    final phaseTasks = <ProductionTaskDraft>[...targetPhase.tasks];
    final insertTaskIndex = phaseTasks.length;
    final flatInsertIndex = _flattenedTaskOffsetForPhase(
      phases: baseDraft.phases,
      phaseIndex: phaseIndex,
    );

    final startLocal = _resolveCalendarDayTaskStart(
      day: day,
      policy: generated.schedulePolicy,
    );
    final dueLocal = _resolveCalendarDayTaskEnd(
      startLocal: startLocal,
      policy: generated.schedulePolicy,
    );

    final nextTaskId = "task_${DateTime.now().microsecondsSinceEpoch}";
    final fallbackRole = targetPhase.tasks.isNotEmpty
        ? targetPhase.tasks.first.roleRequired
        : "farmer";
    final nextRequiredHeadcount = 1;

    final nextDraftTask = ProductionTaskDraft(
      id: nextTaskId,
      title: "Task",
      roleRequired: fallbackRole,
      assignedStaffId: null,
      assignedStaffProfileIds: const <String>[],
      requiredHeadcount: nextRequiredHeadcount,
      weight: 1,
      instructions: "Task added from draft calendar day view.",
      status: ProductionTaskStatus.notStarted,
      completedAt: null,
      completedByStaffId: null,
    );
    phaseTasks.insert(insertTaskIndex, nextDraftTask);

    final updatedPhases = <ProductionPhaseDraft>[...baseDraft.phases];
    updatedPhases[phaseIndex] = targetPhase.copyWith(tasks: phaseTasks);

    final updatedDraft = baseDraft.copyWith(
      phases: updatedPhases,
      totalTasks: baseDraft.totalTasks + 1,
    );

    final nextPreviewTask = ProductionAiDraftTaskPreview(
      id: nextTaskId,
      title: nextDraftTask.title,
      phaseName: targetPhase.name,
      roleRequired: fallbackRole,
      requiredHeadcount: nextRequiredHeadcount,
      assignedCount: 0,
      assignedStaffProfileIds: const <String>[],
      status: "not_started",
      startDate: startLocal.toUtc(),
      dueDate: dueLocal.toUtc(),
      instructions: nextDraftTask.instructions,
      hasShortage: generated.capacity != null
          ? nextRequiredHeadcount >
                generated.capacity!.availableForRole(fallbackRole)
          : false,
    );

    final updatedPreviewTasks = <ProductionAiDraftTaskPreview>[
      ...generated.tasks,
    ];
    final safePreviewInsertIndex = (flatInsertIndex + insertTaskIndex).clamp(
      0,
      updatedPreviewTasks.length,
    );
    updatedPreviewTasks.insert(safePreviewInsertIndex, nextPreviewTask);

    final updatedResult = ProductionAiDraftResult(
      draft: updatedDraft,
      status: generated.status,
      partialIssue: generated.partialIssue,
      message: generated.message,
      summary: generated.summary,
      schedulePolicy: generated.schedulePolicy,
      capacity: generated.capacity,
      warnings: List<String>.from(generated.warnings),
      tasks: updatedPreviewTasks,
    );

    setState(() {
      _generatedDraft = updatedResult;
      // WHY: Index-based overrides are no longer stable after inserting a task.
      _draftTaskOverrides = <int, ProductionDraftTaskOverride>{};
    });

    AppDebug.log(
      _logTag,
      _aiDraftCalendarAddTask,
      extra: {
        "day": formatDateInput(day),
        "phaseNameHint": phaseNameHint,
        "phaseIndex": phaseIndex,
        "flatInsertIndex": safePreviewInsertIndex,
        "taskId": nextTaskId,
      },
    );
    _showSnack(_aiDraftCalendarAddTaskMessage);
  }

  int _resolvePhaseIndexForCalendarPreview({
    required List<ProductionPhaseDraft> phases,
    required String phaseNameHint,
  }) {
    final normalizedHint = phaseNameHint.trim().toLowerCase();
    if (normalizedHint.isEmpty) {
      return 0;
    }

    final exactIndex = phases.indexWhere(
      (phase) => phase.name.trim().toLowerCase() == normalizedHint,
    );
    if (exactIndex >= 0) {
      return exactIndex;
    }

    final partialIndex = phases.indexWhere(
      (phase) =>
          phase.name.trim().toLowerCase().contains(normalizedHint) ||
          normalizedHint.contains(phase.name.trim().toLowerCase()),
    );
    if (partialIndex >= 0) {
      return partialIndex;
    }

    return 0;
  }

  int _flattenedTaskOffsetForPhase({
    required List<ProductionPhaseDraft> phases,
    required int phaseIndex,
  }) {
    var offset = 0;
    for (var index = 0; index < phaseIndex; index += 1) {
      offset += phases[index].tasks.length;
    }
    return offset;
  }

  DateTime _resolveCalendarDayTaskStart({
    required DateTime day,
    required ProductionAiDraftSchedulePolicy? policy,
  }) {
    final firstBlock = policy?.blocks.isNotEmpty == true
        ? policy!.blocks.first
        : null;
    final parsedStart = _parseClockToHourMinute(firstBlock?.start);
    final hour = parsedStart?.$1 ?? 9;
    final minute = parsedStart?.$2 ?? 0;
    return DateTime(day.year, day.month, day.day, hour, minute);
  }

  DateTime _resolveCalendarDayTaskEnd({
    required DateTime startLocal,
    required ProductionAiDraftSchedulePolicy? policy,
  }) {
    final minSlot = policy?.minSlotMinutes ?? 60;
    final safeMinSlot = minSlot.clamp(15, 240);
    var due = startLocal.add(Duration(minutes: safeMinSlot));

    final firstBlock = policy?.blocks.isNotEmpty == true
        ? policy!.blocks.first
        : null;
    final parsedEnd = _parseClockToHourMinute(firstBlock?.end);
    if (parsedEnd != null) {
      final blockEnd = DateTime(
        startLocal.year,
        startLocal.month,
        startLocal.day,
        parsedEnd.$1,
        parsedEnd.$2,
      );
      if (due.isAfter(blockEnd)) {
        due = blockEnd.isAfter(startLocal)
            ? blockEnd
            : startLocal.add(const Duration(minutes: 30));
      }
    }

    return due;
  }

  (int, int)? _parseClockToHourMinute(String? value) {
    final raw = (value ?? "").trim();
    if (raw.isEmpty) {
      return null;
    }
    final parts = raw.split(":");
    if (parts.length < 2) {
      return null;
    }
    final hour = int.tryParse(parts[0]) ?? -1;
    final minute = int.tryParse(parts[1]) ?? -1;
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
      return null;
    }
    return (hour, minute);
  }

  void _onDraftOverridesChanged(
    Map<int, ProductionDraftTaskOverride> overrides,
  ) {
    // WHY: Parent consumes preview staffing edits only when user applies draft.
    _draftTaskOverrides = Map<int, ProductionDraftTaskOverride>.from(overrides);
    AppDebug.log(
      _logTag,
      "ai_draft_preview_overrides_changed",
      extra: {"overrideCount": _draftTaskOverrides.length},
    );
  }

  List<String> _resolveAssignedStaffProfileIds({
    required ProductionTaskDraft baseTask,
    required ProductionDraftTaskOverride? override,
  }) {
    final source = override?.assignedStaffProfileIds != null
        ? override!.assignedStaffProfileIds!
        : baseTask.assignedStaffProfileIds;
    final normalized = source
        .map((value) => value.trim())
        .where((value) => value.isNotEmpty)
        .toSet()
        .toList();
    final legacyAssignedId = baseTask.assignedStaffId?.trim() ?? "";
    if (legacyAssignedId.isNotEmpty && !normalized.contains(legacyAssignedId)) {
      normalized.insert(0, legacyAssignedId);
    }
    return normalized;
  }

  ProductionPlanDraftState _buildDraftWithOverrides(
    ProductionPlanDraftState draft,
  ) {
    if (_draftTaskOverrides.isEmpty) {
      return draft;
    }

    var taskCursor = 0;
    final updatedPhases = draft.phases.map((phase) {
      final updatedTasks = phase.tasks.map((task) {
        final override = _draftTaskOverrides[taskCursor];
        taskCursor += 1;
        if (override == null) {
          return task;
        }

        final nextHeadcount = override.requiredHeadcount != null
            ? (override.requiredHeadcount! < 1
                  ? 1
                  : override.requiredHeadcount!)
            : task.requiredHeadcount;
        final nextAssignedIds = _resolveAssignedStaffProfileIds(
          baseTask: task,
          override: override,
        );
        // WHY: Persisted draft should not carry fewer required slots than selected assignees.
        final normalizedHeadcount = nextAssignedIds.length > nextHeadcount
            ? nextAssignedIds.length
            : nextHeadcount;

        return task.copyWith(
          requiredHeadcount: normalizedHeadcount,
          assignedStaffProfileIds: nextAssignedIds,
          assignedStaffId: nextAssignedIds.isEmpty
              ? null
              : nextAssignedIds.first,
        );
      }).toList();

      return phase.copyWith(tasks: updatedTasks);
    }).toList();

    return draft.copyWith(phases: updatedPhases);
  }

  void _showSnack(String message) {
    // WHY: Snackbars provide lightweight feedback for async actions.
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final controller = ref.read(productionPlanDraftProvider.notifier);
    final isGenerating = _uiState == _AiDraftUiState.generating;
    final generatedDraft = _generatedDraft;
    final generatedSummary = generatedDraft?.summary;
    final summaryValues = [
      (
        label: _aiSummaryTasksLabel,
        value:
            generatedDraft?.tasks.length.toString() ??
            widget.draft.totalTasks.toString(),
      ),
      (
        label: _aiSummaryDaysLabel,
        value:
            generatedSummary?.days.toString() ??
            widget.draft.totalEstimatedDays.toString(),
      ),
      (label: "Weeks", value: generatedSummary?.weeks.toString() ?? "-"),
      (
        label: "Month approx",
        value: generatedSummary?.monthApprox.toString() ?? "-",
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // WHY: Keeps AI attribution visible for manual edits.
        SwitchListTile(
          value: widget.draft.aiGenerated,
          onChanged: controller.updateAiGenerated,
          title: const Text(_aiDraftLabel),
          subtitle: const Text(_aiDraftHelper),
        ),
        const SizedBox(height: _fieldSpacing),
        TextField(
          controller: _assistantPromptCtrl,
          focusNode: _assistantPromptFocusNode,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: _aiAssistantPromptLabel,
            hintText: _aiAssistantPromptHint,
          ),
        ),
        const SizedBox(height: _fieldSpacing),
        // WHY: Button triggers AI draft generation for faster setup.
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: isGenerating ? null : _generateDraft,
            icon: isGenerating
                ? const SizedBox(
                    width: _submitSpinnerSize,
                    height: _submitSpinnerSize,
                    child: CircularProgressIndicator(
                      strokeWidth: _submitSpinnerStroke,
                    ),
                  )
                : const Icon(Icons.auto_awesome),
            label: Text(_aiDraftButtonLabel),
          ),
        ),
        if (_uiState == _AiDraftUiState.success) ...[
          const SizedBox(height: _fieldSpacing),
          _AiInlineStatusBanner(
            message: generatedDraft == null
                ? _aiDraftSuccessInlineMessage
                : _aiDraftReadyToApplyMessage,
            icon: Icons.check_circle_outline,
          ),
        ],
        if (_uiState == _AiDraftUiState.partial &&
            _lastPartialIssue != null) ...[
          const SizedBox(height: _fieldSpacing),
          _AiDraftPartialPanel(
            issue: _lastPartialIssue!,
            onEditDescription: () {
              // WHY: Prompt focus helps users quickly refine context.
              _assistantPromptFocusNode.requestFocus();
            },
            onSelectProduct: () {
              // WHY: Product reminder keeps draft progress moving toward final save.
              _showSnack(_aiDraftPartialProductHint);
            },
            onRetry: _generateDraft,
          ),
        ],
        if (_uiState == _AiDraftUiState.error && _lastError != null) ...[
          const SizedBox(height: _fieldSpacing),
          _AiDraftErrorPanel(
            error: _lastError!,
            showDetails: _showErrorDetails,
            onToggleDetails: () {
              setState(() => _showErrorDetails = !_showErrorDetails);
            },
            onRetry: _generateDraft,
          ),
        ],
        if (widget.draft.aiGenerated) ...[
          const SizedBox(height: _fieldSpacing),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(_fieldSpacing),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _aiSummaryLabel,
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 16,
                  runSpacing: 8,
                  children: summaryValues
                      .map(
                        (item) => RichText(
                          text: TextSpan(
                            style: Theme.of(context).textTheme.bodySmall,
                            children: [
                              TextSpan(text: "${item.label}: "),
                              TextSpan(
                                text: item.value,
                                style: Theme.of(context).textTheme.bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      )
                      .toList(),
                ),
                const SizedBox(height: 8),
                Text(
                  _aiSummaryRisksLabel,
                  style: Theme.of(
                    context,
                  ).textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                if (widget.draft.riskNotes.isEmpty)
                  Text(
                    _aiSummaryNoRisks,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                if (widget.draft.riskNotes.isNotEmpty)
                  ...widget.draft.riskNotes.map(
                    (risk) => Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: Text(
                        "- $risk",
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
        if (generatedDraft != null) ...[
          const SizedBox(height: _fieldSpacing),
          if (generatedDraft.warnings.isNotEmpty)
            _AiWarningsCard(warnings: generatedDraft.warnings),
          if (generatedDraft.warnings.isNotEmpty)
            const SizedBox(height: _fieldSpacing),
          ProductionDraftCalendarPreview(
            tasks: generatedDraft.tasks,
            schedulePolicy: generatedDraft.schedulePolicy,
            staffProfiles: widget.staffProfiles,
            onOverridesChanged: _onDraftOverridesChanged,
            onAddTaskForDay: _onPreviewAddTaskForDay,
          ),
          const SizedBox(height: _fieldSpacing),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _applyGeneratedDraft,
              icon: const Icon(Icons.check_circle_outline),
              label: const Text(_aiDraftApplyButtonLabel),
            ),
          ),
        ],
      ],
    );
  }

  ProductionAiDraftError _toAiDraftError(Object error) {
    if (error is ProductionAiDraftError) {
      return error;
    }
    return ProductionAiDraftError(
      message: _aiDraftFailureMessage,
      classification: "UNKNOWN_PROVIDER_ERROR",
      errorCode: "PRODUCTION_AI_DRAFT_FAILED",
      resolutionHint:
          "Retry the draft generation and adjust the assistant brief.",
      details: {_extraErrorKey: error.toString()},
      retryAllowed: true,
      retryReason: "unexpected_error",
      statusCode: 500,
    );
  }
}

class _AiInlineStatusBanner extends StatelessWidget {
  final String message;
  final IconData icon;

  const _AiInlineStatusBanner({required this.message, required this.icon});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: theme.colorScheme.onPrimaryContainer),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              message,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onPrimaryContainer,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AiWarningsCard extends StatelessWidget {
  final List<String> warnings;

  const _AiWarningsCard({required this.warnings});

  @override
  Widget build(BuildContext context) {
    final colors = AppStatusBadgeColors.fromTheme(
      theme: Theme.of(context),
      tone: AppStatusTone.warning,
    );
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: colors.background,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: colors.foreground.withValues(alpha: 0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Warnings",
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: colors.foreground,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          ...warnings.map(
            (warning) => Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Text(
                "- $warning",
                style: Theme.of(
                  context,
                ).textTheme.bodySmall?.copyWith(color: colors.foreground),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AiDraftPartialPanel extends StatelessWidget {
  final ProductionAiDraftPartialIssue issue;
  final VoidCallback onEditDescription;
  final VoidCallback onSelectProduct;
  final VoidCallback onRetry;

  const _AiDraftPartialPanel({
    required this.issue,
    required this.onEditDescription,
    required this.onSelectProduct,
    required this.onRetry,
  });

  String _resolveDescription() {
    switch (issue.issueType) {
      case _aiDraftPartialProductIssue:
        return _aiDraftPartialProductDescription;
      case _aiDraftPartialDateIssue:
        return _aiDraftPartialDateDescription;
      case _aiDraftPartialSchemaIssue:
        return _aiDraftPartialSchemaDescription;
      case _aiDraftPartialContextIssue:
        return _aiDraftPartialContextDescription;
      default:
        return issue.message.trim().isNotEmpty
            ? issue.message
            : _aiDraftPartialContextDescription;
    }
  }

  String _resolveGoodNewsValue() {
    if (issue.issueType == _aiDraftPartialSchemaIssue) {
      return _aiDraftPartialSchemaGoodNewsValue;
    }
    return _aiDraftPartialGoodNewsValue;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final description = _resolveDescription();
    final goodNewsValue = _resolveGoodNewsValue();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: theme.colorScheme.secondaryContainer,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.warning_amber_rounded,
                color: theme.colorScheme.onSecondaryContainer,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _aiDraftPartialTitle,
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: theme.colorScheme.onSecondaryContainer,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            description,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSecondaryContainer,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _aiDraftPartialGoodNewsLabel,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSecondaryContainer,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            goodNewsValue,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSecondaryContainer,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _aiDraftPartialActionsLabel,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSecondaryContainer,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          _AiPartialActionLine(
            icon: Icons.edit_outlined,
            label: _aiDraftPartialEditAction,
          ),
          _AiPartialActionLine(
            icon: Icons.inventory_2_outlined,
            label: _aiDraftPartialSelectProductAction,
          ),
          _AiPartialActionLine(
            icon: Icons.refresh,
            label: _aiDraftPartialRetryAction,
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton.icon(
                onPressed: onEditDescription,
                icon: const Icon(Icons.edit_outlined),
                label: const Text(_aiDraftPartialEditAction),
              ),
              OutlinedButton.icon(
                onPressed: onSelectProduct,
                icon: const Icon(Icons.inventory_2_outlined),
                label: const Text(_aiDraftPartialSelectProductAction),
              ),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text(_aiDraftPartialRetryAction),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _AiPartialActionLine extends StatelessWidget {
  final IconData icon;
  final String label;

  const _AiPartialActionLine({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Row(
        children: [
          Icon(icon, size: 14, color: theme.colorScheme.onSecondaryContainer),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              label,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onSecondaryContainer,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AiDraftErrorPanel extends StatelessWidget {
  final ProductionAiDraftError error;
  final bool showDetails;
  final VoidCallback onToggleDetails;
  final VoidCallback onRetry;

  const _AiDraftErrorPanel({
    required this.error,
    required this.showDetails,
    required this.onToggleDetails,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final detailsLines = <String>[
      if (error.details["missing"] is List)
        "Missing: ${(error.details["missing"] as List).join(", ")}",
      if (error.details["invalid"] is List)
        "Invalid: ${(error.details["invalid"] as List).join(", ")}",
      if (error.details["providerMessage"] != null &&
          error.details["providerMessage"].toString().trim().isNotEmpty)
        "Provider: ${error.details["providerMessage"]}",
    ].where((line) => line.trim().isNotEmpty).toList();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_fieldSpacing),
      decoration: BoxDecoration(
        color: theme.colorScheme.errorContainer.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: theme.colorScheme.error),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _aiDraftErrorTitle,
            style: theme.textTheme.titleSmall?.copyWith(
              color: theme.colorScheme.error,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            "${error.classification} - ${error.errorCode}",
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurface,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            error.resolutionHint,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              OutlinedButton.icon(
                onPressed: error.retryAllowed ? onRetry : null,
                icon: const Icon(Icons.refresh),
                label: const Text(_aiDraftRetryLabel),
              ),
              const SizedBox(width: 8),
              if (detailsLines.isNotEmpty)
                TextButton(
                  onPressed: onToggleDetails,
                  child: Text(
                    showDetails
                        ? _aiDraftErrorDetailsHideLabel
                        : _aiDraftErrorDetailsLabel,
                  ),
                ),
            ],
          ),
          if (showDetails && detailsLines.isNotEmpty) ...[
            const SizedBox(height: 8),
            for (final line in detailsLines)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  line,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }
}
